const express = require('express');
const router = express.Router();
const controller = require('../controllers/userController');

router.get('/', controller.readAllUser);
router.get('/:id', controller.readUserById);
router.post('/', controller.createNewUser);
router.put('/:id', controller.updateUserById);
router.delete('/:id', controller.deleteUserById);

module.exports = router;