const pool = require('../services/db');
module.exports.selectAll = (callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM User;
    `;

pool.query(SQLSTATMENT, callback);
}

module.exports.selectByuserId = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM User
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.insertuserSingle = (data, callback) => {
    const SQL = `INSERT INTO User (username, email, password) VALUES (?, ?, ?);`;
    const VALUES = [data.username, data.email, data.password];
    pool.query(SQL, VALUES, callback);
}
module.exports.updateuserById = (data, callback) => {
    const SQLSTATEMENT = `
        UPDATE User
        SET username = ?, email = ?, password = ?
        WHERE id = ?;
    `;
    const VALUES = [data.username, data.email, data.password, data.id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.deleteuserById = (data, callback) =>
{
    const SQLSTATMENT = `
    DELETE FROM User
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}