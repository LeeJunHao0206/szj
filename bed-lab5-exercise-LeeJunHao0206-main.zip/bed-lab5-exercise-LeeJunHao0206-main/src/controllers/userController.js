const model = require("../models/userModel.js");

module.exports.readAllUser = (req, res, next) =>
{
    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readAllPlayer:", error);
            res.status(500).json(error);
        } 
        else res.status(200).json(results);
    }

    model.selectAll(callback);
}


module.exports.readUserById = (req, res, next) =>
{
    const data = {
        id: req.params.id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readUserById:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "User not found"
                });
            }
            else res.status(200).json(results[0]);
        }
    }

    model.selectByuserId(data, callback);
}

module.exports.createNewUser = (req, res, next) => {
    if (!req.body.username) {
        res.status(400).send("Error: username is undefined");
        return;
    }

    const data = {
        username: req.body.username,   // Must match DB column
        email: req.body.email,
        password: req.body.password
    };

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error createNewUser:", error);
            res.status(500).json(error);
        } else {
            // Assuming 'results.insertId' gives the new user's id
            res.status(201).json({
                message: "User created successfully",
                user: {
                    id: results.insertId,
                    username: data.username,
                    email: data.email,
                    created_on: new Date(),
                    updated_on: new Date(),
                    last_login_on: null
                }
            });
        }
    };

    model.insertuserSingle(data, callback);
};

module.exports.updateUserById = (req, res, next) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        res.status(400).json({
            message: "Error: username, email, or password is undefined"
        });
        return;
    }

    const data = {
        id: req.params.id,
        username,
        email,
        password
    };

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error updateUserById:", error);
            res.status(500).json(error);
        } else {
            if (results.affectedRows === 0) {
                res.status(404).json({ message: "User not found" });
            } else {
                // 204 No Content → must not send any body
                res.status(204).send();
            }
        }
    };

    model.updateuserById(data, callback);
};



     module.exports.deleteUserById= (req, res, next) =>
    {
        const data = {
            id: req.params.id
        }
    
        const callback = (error, results, fields) => {
            if (error) {
                console.error("Error deletePlayerById:", error);
                res.status(500).json(error);
            } else {
                if(results.affectedRows == 0) 
                {
                    res.status(404).json({
                        message: "Player not found"
                    });
                }
                else res.status(204).send(); // 204 No Content            
            }
        }
    
        model.deleteuserById(data, callback);
    }