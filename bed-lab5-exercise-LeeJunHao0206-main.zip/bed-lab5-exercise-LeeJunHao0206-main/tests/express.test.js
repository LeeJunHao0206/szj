/**
 * Express.js API Testing Suite for Students
 * 
 * This test file validates your Express.js application's REST API endpoints.
 * Each test is designed to help you understand what went wrong and how to fix it.
 * 
 * Test Structure:
 * - GET Routes: Testing data retrieval
 * - POST Routes: Testing data creation  
 * - PUT Routes: Testing data updates
 * - DELETE Routes: Testing data deletion
 * - Database Models: Testing direct database operations
 * - Configuration: Testing project setup
 * 
 * How to read test failures:
 * - Look for the ❌ emoji to identify failed tests
 * - Read the detailed error messages that explain what was expected vs what happened
 * - Check the "withContext" messages for specific guidance on how to fix issues
 * 
 * Running tests: npm test
 */

const model = require("../src/models/playerModel");
const pool = require("../src/services/db");

const request = require("supertest");
const app = require("../src/app"); // Replace 'app' with the path to your Express.js application entry point
const fs = require("fs");

// Global test configuration
jest.setTimeout(10000); // 10 second timeout for all tests

// Global error handler for uncaught exceptions during tests
beforeAll(() => {
  // Set up global error handling to prevent test crashes
  process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    // Don't exit the process, just log the error
  });
});

// Clean up after all tests
afterAll(async () => {
  // Close database connections if they exist
  try {
    if (pool && pool.end) {
      await pool.end();
    }
  } catch (error) {
    console.log('Database cleanup completed');
  }
});

describe("Testing GET Routes - Reading Data from the Server", () => {
  test("should retrieve all players (GET /player) and return initial 3 players", (done) => {
    request(app)
      .get("/player")
      .then((response) => {
        expect(response.status).toBeWithContext(
          200, 
          `Expected status 200 (OK) when fetching all players. Got ${response.status}. Check if your GET /player route is properly implemented and returns a successful response.`
        );
        
        expect(response.body.length).toEqualWithContext(
          3,
          `Expected exactly 3 initial players in the database, but got ${response.body.length}. Check your initial data setup - you should have 3 players by default.`
        );

        done();
      });
  });
});

describe("Testing POST Routes - Creating New Data", () => {
  test("should reject player creation when no data is provided (POST /player)", (done) => {
    request(app)
      .post("/player")
      .send({})
      .then((response) => {
        expect(response.status).toBeWithContext(
          400,
          "Expected status 400 (Bad Request) when creating a player without required data. Your route should validate that name and level are provided."
        );
        done();
      })
      .catch((error) => {
        done(`Request failed: ${error.message}. Make sure your POST /player route exists and handles empty requests properly.`);
      });
  });

  test("should successfully create a new player with valid data (POST /player)", (done) => {
    const newPlayer = {
      name: "Jessie",
      level: 1,
    };
    
    request(app)
      .post("/player")
      .send(newPlayer)
      .then((response) => {
        expect(response.status).toBeWithContext(
          201,
          `Expected status 201 (Created) when creating a player with valid data: ${JSON.stringify(newPlayer)}. Check if your POST route properly handles player creation and returns the correct status code.`
        );
        done();
      })
      .catch((error) => {
        done(`Request failed: ${error.message}. Make sure your POST /player route can handle valid player data.`);
      });
  });

  test("should be able to retrieve the newly created player by ID (GET /player/4)", async () => {
    const response = await request(app).get("/player/4");
    
    expect(response.status).toBeWithContext(
      200,
      "Expected status 200 (OK) when fetching player ID 4 (the newly created player). Check if your GET /player/:id route works correctly."
    );
    
    expect(response.body.name).toEqualWithContext(
      "Jessie",
      "Expected the new player's name to be 'Jessie'. Check if your POST route properly saves the player data."
    );
    
    expect(response.body.level).toEqualWithContext(
      1,
      "Expected the new player's level to be 1. Check if your POST route properly saves all player fields."
    );
  });

  test("should have 4 total players after creating one new player (GET /player)", async () => {
    const response = await request(app).get("/player");
    
    expect(response.status).toBeWithContext(
      200,
      "Expected status 200 (OK) when fetching all players after creation."
    );
    
    expect(response.body.length).toEqualWithContext(
      4,
      "Expected 4 players total (3 initial + 1 newly created). This suggests the POST operation may not have persisted the data correctly."
    );
  });
});

describe("Testing PUT Routes - Updating Existing Data", () => {
  test("should reject update when required data is missing (PUT /player/:id)", async () => {
    const response = await request(app).put("/player/4").send({});
    
    expect(response.status).toBeWithContext(
      400,
      "Expected status 400 (Bad Request) when trying to update a player without providing name or level. Your PUT route should validate that required fields are present."
    );
    
    expect(response.body).toEqualWithContext(
      { message: "Error: name or level is undefined" },
      "Expected error message about missing name or level fields. Check if your PUT route properly validates input data."
    );
  });

  test("should return 404 when trying to update a non-existent player (PUT /player/:id)", async () => {
    const updateData = {
      name: "Super Jessie",
      level: 100,
    };
    const response = await request(app).put("/player/6").send(updateData);
    
    expect(response.status).toBeWithContext(
      404,
      "Expected status 404 (Not Found) when trying to update player ID 6 which doesn't exist. Your PUT route should check if the player exists before attempting to update."
    );
    
    expect(response.body).toEqualWithContext(
      { message: "Player not found" },
      "Expected 'Player not found' message when trying to update a non-existent player."
    );
  });

  test("should successfully update an existing player (PUT /player/:id)", async () => {
    const updateData = {
      name: "Super Ash",
      level: 100,
    };
    const response = await request(app).put("/player/1").send(updateData);
    
    expect(response.status).toBeWithContext(
      204,
      `Expected status 204 (No Content) when successfully updating player ID 1 with data: ${JSON.stringify(updateData)}. Check if your PUT route properly handles valid updates.`
    );
  });

  test("should verify the player was actually updated (GET /player/:id after PUT)", async () => {
    const response = await request(app).get("/player/1");
    
    expect(response.status).toBeWithContext(
      200,
      "Expected status 200 (OK) when fetching the updated player to verify changes were saved."
    );
    
    expect(response.body.name).toEqualWithContext(
      "Super Ash",
      "Expected updated player name to be 'Super Ash'. The PUT operation may not have properly saved the changes."
    );
    
    expect(response.body.level).toEqualWithContext(
      100,
      "Expected updated player level to be 100. The PUT operation may not have properly saved all fields."
    );
  });
});

describe("Testing DELETE Routes - Removing Data", () => {
  test("should successfully delete an existing player (DELETE /player/:id)", async () => {
    const response = await request(app).delete("/player/2");
    
    expect(response.status).toBeWithContext(
      204,
      "Expected status 204 (No Content) when successfully deleting player ID 2. Check if your DELETE route properly handles player deletion and returns the correct status code."
    );
  });

  test("should return 404 when trying to access deleted player (GET /player/:id after DELETE)", async () => {
    const response = await request(app).get("/player/2");
    
    expect(response.status).toBeWithContext(
      404,
      "Expected status 404 (Not Found) when trying to fetch player ID 2 after deletion. This confirms the player was actually removed from the database. If this fails, the DELETE operation may not have worked properly."
    );
  });
});

describe("Testing Project Configuration - package.json Validation", () => {
  let packageJson;

  beforeAll(() => {
    // Read the package.json file and parse it as JSON
    const packageJsonContents = fs.readFileSync("package.json", "utf8");
    packageJson = JSON.parse(packageJsonContents);
  });

  it("should have a 'start' script configured for production", () => {
    expect(packageJson).toHavePropertyWithContext(
      "scripts.start",
      "Missing 'start' script in package.json. Add a 'start' script in the 'scripts' section to define how to run your application in production."
    );
  });

  it("should have a 'dev' script configured for development", () => {
    expect(packageJson).toHavePropertyWithContext(
      "scripts.dev",
      "Missing 'dev' script in package.json. Add a 'dev' script in the 'scripts' section to define how to run your application in development mode (usually with nodemon for auto-restart)."
    );
  });

  it("should have correct values for start and dev scripts", () => {
    const startScript = packageJson.scripts?.start;
    const devScript = packageJson.scripts?.dev;

    expect(startScript).toEqualWithContext(
      "node index.js",
      "Expected start script to be 'node index.js'. The start script should run your main application file with Node.js."
    );
    
    expect(devScript).toEqualWithContext(
      "nodemon index.js",
      "Expected dev script to be 'nodemon index.js'. The dev script should use nodemon to automatically restart your application when files change."
    );
  });

  it("should have Express.js as a dependency", () => {
    expect(packageJson).toHavePropertyWithContext(
      "dependencies.express",
      "Missing Express.js dependency. Run 'npm install express' to add Express.js to your project dependencies. Express is required to create your web server."
    );
  });

  it("should have nodemon as a dependency for development", () => {
    expect(packageJson).toHavePropertyWithContext(
      "dependencies.nodemon",
      "Missing nodemon dependency. Run 'npm install nodemon' to add nodemon to your project dependencies. Nodemon automatically restarts your application when you make changes during development."
    );
  });
});

describe("Testing Database Models - Direct Database Operations", () => {
  test("selectById should retrieve player data with the given id", (done) => {
    const mockData = {
      id: 1,
    };

    const mockCallback = (error, results) => {
      expect(error).toBeWithContext(
        null,
        `Expected no error when calling selectById with valid ID. Got error: ${error}. Check your database connection and playerModel.selectById implementation.`
      );
      
      expect(results).toEqualWithContext(
        expect.any(Object),
        "Expected selectById to return an object representing the player data. Check if your selectById function properly returns player information."
      );
      
      done();
    };

    model.selectById(mockData, mockCallback);
  });

  test("selectAll should retrieve all player data", (done) => {
    const mockCallback = (error, results) => {
      expect(error).toBeWithContext(
        null,
        `Expected no error when calling selectAll. Got error: ${error}. Check your database connection and playerModel.selectAll implementation.`
      );
      
      expect(results).toEqualWithContext(
        expect.any(Array),
        "Expected selectAll to return an array of player objects. Check if your selectAll function properly returns all players from the database."
      );
      
      expect(results[0].name).toEqualWithContext(
        "Super Ash",
        "Expected the first player's name to be 'Super Ash' (after the update). Check if your database has the correct initial data and the previous update worked."
      );
      
      expect(results[1].id).toEqualWithContext(
        3,
        "Expected the second player's ID to be 3. Check your database structure and initial data setup."
      );
      
      expect(results[2].level).toEqualWithContext(
        1,
        "Expected the third player's level to be 1. Check if the newly created player has the correct level value."
      );
      
      done();
    };
    
    model.selectAll(mockCallback);
  });

  test("insertSingle should insert a new player into the database", (done) => {
    const mockData = {
      name: "Jessie",
      level: 1,
    };

    const mockCallback = (error, results) => {
      expect(error).toBeWithContext(
        null,
        `Expected no error when inserting a new player with data: ${JSON.stringify(mockData)}. Got error: ${error}. Check your database connection and playerModel.insertSingle implementation.`
      );
      
      expect(results).toEqualWithContext(
        expect.any(Object),
        "Expected insertSingle to return an object with insert operation details. Check if your insertSingle function properly handles the database insert operation."
      );
      
      expect(results.affectedRows).toEqualWithContext(
        1,
        "Expected exactly 1 row to be affected when inserting a single player. Check if your INSERT query is working correctly."
      );
      
      done();
    };
    
    model.insertSingle(mockData, mockCallback);
  });

  test("updateById should update the player with the given id", (done) => {
    const mockData = {
      id: 1,
      name: "Super Ash",
      level: 100
    };

    const mockCallback = (error, results) => {
      expect(error).toBeWithContext(
        null,
        `Expected no error when updating player with data: ${JSON.stringify(mockData)}. Got error: ${error}. Check your database connection and playerModel.updateById implementation.`
      );
      
      expect(results).toEqualWithContext(
        expect.any(Object),
        "Expected updateById to return an object with update operation details. Check if your updateById function properly handles the database update operation."
      );
      
      console.log(results);
      done();
    };
    
    model.updateById(mockData, mockCallback);
  });

  test("deleteById should delete the player with the given id", (done) => {
    const mockData = {
      id: 3
    };

    const mockCallback = (error, results) => {
      expect(error).toBeWithContext(
        null,
        `Expected no error when deleting player with ID: ${mockData.id}. Got error: ${error}. Check your database connection and playerModel.deleteById implementation.`
      );
      
      expect(results).toEqualWithContext(
        expect.any(Object),
        "Expected deleteById to return an array with delete operation details. Check if your deleteById function properly handles the database delete operation."
      );
      
      console.log(results);
      done();
    };
    
    model.deleteById(mockData, mockCallback);
  });
});

describe("Testing SQL Query Construction - Verifying Model Functions", () => {
  test("selectAll should call pool.query with the correct SQL query", () => {
    const mockCallback = () => {};
    const querySpy = jest.spyOn(pool, "query");

    model.selectAll(mockCallback);

    // First check that pool.query was actually called
    expect(querySpy).toHaveBeenCalled();
    
    expect(querySpy).toHaveBeenCalledWith(
      expect.stringContaining("SELECT * FROM Player"),
      mockCallback
    );

    // Additional validation for educational purposes
    try {
      if (querySpy.mock.calls.length > 0) {
        const actualQuery = querySpy.mock.calls[0][0];
        expect(actualQuery).toContainSQLPatternDynamic(
          "SELECT * FROM Player",
          {
            operation: "selectAll query",
            field: "SELECT statement",
            suggestions: [
              "Make sure to use 'SELECT * FROM Player' to fetch all columns",
              "Check if your selectAll function constructs the correct SQL query",
              "Verify the table name is 'Player' (case-sensitive)"
            ]
          }
        );
      }
    } catch (error) {
      throw new Error(`❌ Test validation failed: ${error.message}`);
    } finally {
      querySpy.mockRestore();
    }
  });

  test("selectById should call pool.query with correct SQL query and parameters", () => {
    const mockData = { id: 1 };
    const mockCallback = () => {};
    let querySpy;
    
    try {
      querySpy = jest.spyOn(pool, "query");
      model.selectById(mockData, mockCallback);

      // First check that pool.query was actually called
      expect(querySpy).toHaveBeenCalled();

      expect(querySpy).toHaveBeenCalledWith(
        expect.stringContaining("SELECT * FROM Player") &&
          expect.stringContaining("WHERE id = ?"),
        [1],
        mockCallback
      );

      // Additional validation for educational purposes
      if (querySpy.mock.calls.length > 0) {
        const [actualQuery, actualParams] = querySpy.mock.calls[0];
        
        // Break down SQL validation into components
        expect(actualQuery).toContainSQLPatternDynamic(
          "SELECT * FROM Player",
          {
            operation: "selectById query - SELECT clause",
            field: "SELECT statement",
            suggestions: [
              "Use 'SELECT * FROM Player' to fetch all columns from Player table",
              "Verify the table name is 'Player' (case-sensitive)",
              "Make sure you're selecting all columns with *"
            ]
          }
        );
        
        expect(actualQuery).toContainSQLPatternDynamic(
          "WHERE id = ?",
          {
            operation: "selectById query - WHERE clause",
            field: "WHERE condition",
            suggestions: [
              "Use 'WHERE id = ?' to filter by the ID parameter",
              "Ensure you're using '?' as a placeholder for the ID parameter",
              "Check that your WHERE clause filters by 'id' field"
            ]
          }
        );
        
        expect(actualParams).toEqualWithContext(
          expect.arrayContaining([1]),
          `Parameter Error: Expected parameters [1] but got: ${JSON.stringify(actualParams)}

🔧 Fix: Check your selectById function in playerModel.js:
   - Make sure you're passing [data.id] as the second parameter to pool.query
   - Verify you're using ? as placeholder in your SQL query`
        );
      }
    } catch (error) {
      throw new Error(`❌ Test execution failed: ${error.message}`);
    } finally {
      if (querySpy) {
        querySpy.mockRestore();
      }
    }
  });

  test("insertSingle should call pool.query with correct SQL query and parameters", () => {
    const mockData = { name: "Jessie", level: 1 };
    const mockCallback = () => {};
    let querySpy;
    
    try {
      querySpy = jest.spyOn(pool, "query");
      model.insertSingle(mockData, mockCallback);

      // First check that pool.query was actually called
      expect(querySpy).toHaveBeenCalled();

      expect(querySpy).toHaveBeenCalledWith(
        expect.stringContaining("INSERT INTO Player") &&
          expect.stringContaining("VALUES (?, ?)"),
          expect.arrayContaining(["Jessie", 1]),
        mockCallback
      );

      // Additional validation for educational purposes  
      if (querySpy.mock.calls.length > 0) {
        const [actualQuery, actualParams] = querySpy.mock.calls[0];
        
        // Break down SQL validation into components
        expect(actualQuery).toContainSQLPatternDynamic(
          "INSERT INTO Player",
          {
            operation: "insertSingle query - INSERT clause",
            field: "INSERT statement",
            suggestions: [
              "Use 'INSERT INTO Player' to specify the target table",
              "Verify the table name is 'Player' (case-sensitive)",
              "Make sure you're using INSERT INTO syntax"
            ]
          }
        );
        
        expect(actualQuery).toContainSQLPatternDynamic(
          "(name, level)",
          {
            operation: "insertSingle query - column specification",
            field: "Column names in parentheses",
            suggestions: [
              "Specify column names: '(name, level)' after the table name",
              "Ensure both 'name' and 'level' columns are specified",
              "Use parentheses around the column names"
            ]
          }
        );
        
        expect(actualQuery).toContainSQLPatternDynamic(
          "VALUES (?, ?)",
          {
            operation: "insertSingle query - VALUES clause",
            field: "VALUES with placeholders",
            suggestions: [
              "Use 'VALUES (?, ?)' with exactly 2 question marks",
              "Match the number of ? placeholders to the number of columns",
              "Ensure VALUES clause follows the column specification"
            ]
          }
        );
        
        expect(actualParams).toEqualWithContext(
          expect.arrayContaining(["Jessie", 1]),
          `Parameter Error: Expected parameters to contain ["Jessie", 1] but got: ${JSON.stringify(actualParams)}

🔧 Fix: Make sure you're passing [data.name, data.level] as parameters`
        );
      }
    } catch (error) {
      throw new Error(`❌ Test execution failed: ${error.message}`);
    } finally {
      if (querySpy) {
        querySpy.mockRestore();
      }
    }
  });

  test("updateById should call pool.query with correct SQL query and parameters", () => {
    const mockData = { name: "Super Brock", level: 100, id: 2 };
    const mockCallback = () => {};
    let querySpy;
    
    try {
      querySpy = jest.spyOn(pool, "query");
      model.updateById(mockData, mockCallback);

      // First check that pool.query was actually called
      expect(querySpy).toHaveBeenCalled();

      expect(querySpy).toHaveBeenCalledWith(
        expect.stringContaining("UPDATE Player") &&
          expect.stringContaining("SET") &&
          expect.stringContaining("name = ?") && 
          expect.stringContaining("level = ?") &&
          expect.stringContaining("WHERE id = ?"),
          expect.arrayContaining(["Super Brock", 100, 2]),
        mockCallback
      );

      // Additional validation for educational purposes
      if (querySpy.mock.calls.length > 0) {
        const [actualQuery, actualParams] = querySpy.mock.calls[0];
        
        // Break down SQL validation into components
        expect(actualQuery).toContainSQLPatternDynamic(
          "UPDATE Player",
          {
            operation: "updateById query - UPDATE clause",
            field: "UPDATE statement",
            suggestions: [
              "Use 'UPDATE Player' to specify the table to update",
              "Verify the table name is 'Player' (case-sensitive)",
              "Make sure you're using UPDATE syntax"
            ]
          }
        );
        
        expect(actualQuery).toContainSQLPatternDynamic(
          "SET name = ?",
          {
            operation: "updateById query - SET name clause",
            field: "SET clause for name",
            suggestions: [
              "Use 'SET name = ?' to update the name field",
              "Ensure you're using '?' as a placeholder for the name parameter",
              "Check that 'name' field is being set correctly"
            ]
          }
        );
        
        expect(actualQuery).toContainSQLPatternDynamic(
          "level = ?",
          {
            operation: "updateById query - SET level clause",
            field: "SET clause for level",
            suggestions: [
              "Use 'level = ?' to update the level field",
              "Ensure you're using '?' as a placeholder for the level parameter",
              "Check that 'level' field is being set correctly"
            ]
          }
        );
        
        expect(actualQuery).toContainSQLPatternDynamic(
          "WHERE id = ?",
          {
            operation: "updateById query - WHERE clause",
            field: "WHERE condition",
            suggestions: [
              "Use 'WHERE id = ?' to specify which player to update",
              "Ensure you're using '?' as a placeholder for the ID parameter",
              "Check that your WHERE clause filters by 'id' field"
            ]
          }
        );
        
        expect(actualParams).toEqualWithContext(
          expect.arrayContaining(["Super Brock", 100, 2]),
          `Parameter Error: Expected exactly 3 parameters [name, level, id] but got: ${JSON.stringify(actualParams)}

🔧 Fix: Make sure you're passing [data.name, data.level, data.id] as parameters`
        );
      }
    } catch (error) {
      // Graceful error handling to prevent test suite crashes
      throw new Error(`❌ Test execution failed: ${error.message}

🔧 This test failed due to an unexpected error. Check:
   - playerModel.js updateById function exists and is properly defined
   - Database connection is working
   - No syntax errors in your SQL query`);
    } finally {
      // Always restore the spy to prevent test pollution
      if (querySpy) {
        querySpy.mockRestore();
      }
    }
  });

  test("deleteById should call pool.query with correct SQL query and parameters", () => {
    const mockData = { id: 1 };
    const mockCallback = () => {};
    let querySpy;
    
    try {
      querySpy = jest.spyOn(pool, "query");
      model.deleteById(mockData, mockCallback);

      // First check that pool.query was actually called
      expect(querySpy).toHaveBeenCalled();

      expect(querySpy).toHaveBeenCalledWith(
        expect.stringContaining("DELETE FROM Player") &&
          expect.stringContaining("WHERE id = ?"),
          expect.arrayContaining([1]),
        mockCallback
      );

      // Additional validation for educational purposes - using proper Jest assertions
      if (querySpy.mock.calls.length > 0) {
        const [actualQuery, actualParams] = querySpy.mock.calls[0];
        
        // Break down SQL validation into components
        expect(actualQuery).toContainSQLPatternDynamic(
          "DELETE FROM Player",
          {
            operation: "deleteById query - DELETE clause",
            field: "DELETE statement",
            suggestions: [
              "Use 'DELETE FROM Player' to specify the table to delete from",
              "Verify the table name is 'Player' (case-sensitive)",
              "Make sure you're using DELETE FROM syntax (not REMOVE)"
            ]
          }
        );
        
        expect(actualQuery).toContainSQLPatternDynamic(
          "WHERE id = ?",
          {
            operation: "deleteById query - WHERE clause",
            field: "WHERE condition",
            suggestions: [
              "Use 'WHERE id = ?' to specify which player to delete",
              "Ensure you're using '?' as a placeholder for the ID parameter",
              "Check that your WHERE clause filters by 'id' field"
            ]
          }
        );
        
        expect(actualParams).toEqualWithContext(
          expect.arrayContaining([1]),
          `Parameter Error: Expected parameters [1] but got: ${JSON.stringify(actualParams)}

🔧 Fix: Check your deleteById function - make sure you're passing [data.id] as parameters`
        );
      }
    } catch (error) {
      // Graceful error handling to prevent test suite crashes
      throw new Error(`❌ Test execution failed: ${error.message}

🔧 This test failed due to an unexpected error. Check:
   - playerModel.js deleteById function exists and is properly defined
   - Database connection is working
   - No syntax errors in your SQL query`);
    } finally {
      // Always restore the spy to prevent test pollution
      if (querySpy) {
        querySpy.mockRestore();
      }
    }
  });
});


describe("Testing User Routes - Basic Exercise Extensions", () => {
  test("should retrieve all users (GET /user)", (done) => {
    request(app)
      .get("/user")
      .then((response) => {
        expect(response.status).toBeWithContext(
          200,
          `Expected status 200 (OK) when fetching all users. Got ${response.status}. Check if your GET /user route is properly implemented.`
        );
        
        expect(response.body.length).toEqualWithContext(
          2,
          `Expected exactly 2 initial users in the database, but got ${response.body.length}. Check your initial user data setup.`
        );
        
        done();
      });
  });
});

describe("Testing User POST Routes - Creating New Users", () => {
  test("should reject user creation when no data is provided (POST /user)", (done) => {
    request(app)
      .post("/user")
      .send({})
      .then((response) => {
        expect(response.status).toBeWithContext(
          400,
          "Expected status 400 (Bad Request) when creating a user without required data. Your route should validate that username, email, and password are provided."
        );
        done();
      });
  });

  test("should successfully create a new user with valid data (POST /user)", (done) => {
    const newUser = {
      "username": "joanne.goh",
      "email": "joanne.goh@example.com",
      "password": "password123"
    };
    
    request(app)
      .post("/user")
      .send(newUser)
      .then((response) => {
        expect(response.status).toBeWithContext(
          201,
          `Expected status 201 (Created) when creating a user with valid data: ${JSON.stringify(newUser)}. Check if your POST /user route properly handles user creation.`
        );
        done();
      });
  });

  test("should be able to retrieve the newly created user by ID (GET /user/3)", async () => {
    const response = await request(app).get("/user/3");
    
    expect(response.status).toBeWithContext(
      200,
      "Expected status 200 (OK) when fetching user ID 3 (the newly created user). Check if your GET /user/:id route works correctly."
    );
    
    expect(response.body.username).toEqualWithContext(
      "joanne.goh",
      "Expected the new user's username to be 'joanne.goh'. Check if your POST route properly saves the user data."
    );
    
    expect(response.body.email).toEqualWithContext(
      "joanne.goh@example.com",
      "Expected the new user's email to be 'joanne.goh@example.com'. Check if your POST route properly saves all user fields."
    );
  });

  test("should have 3 total users after creating one new user (GET /user)", async () => {
    const response = await request(app).get("/user");
    
    expect(response.status).toBeWithContext(
      200,
      "Expected status 200 (OK) when fetching all users after creation."
    );
    
    expect(response.body.length).toEqualWithContext(
      3,
      "Expected 3 users total (2 initial + 1 newly created). This suggests the POST operation may not have persisted the data correctly."
    );
  });
});

describe("Testing User PUT Routes - Updating User Data", () => {
  test("should return 404 when trying to update a non-existent user (PUT /user/:id)", async () => {
    const updateData = {
      "username": "jane.goh",
      "email": "jane.goh@example.com",
      "password": "newpassword123"
    };
    const response = await request(app).put("/user/6").send(updateData);
    
    expect(response.status).toBeWithContext(
      404,
      "Expected status 404 (Not Found) when trying to update user ID 6 which doesn't exist. Your PUT route should check if the user exists before attempting to update."
    );
    
    expect(response.body).toEqualWithContext(
      { message: "User not found" },
      "Expected 'User not found' message when trying to update a non-existent user."
    );
  });

  test("should successfully update an existing user (PUT /user/:id)", async () => {
    const updateData = {
      "username": "jane.goh",
      "email": "jane.goh@example.com", 
      "password": "newpassword123"
    };
    const response = await request(app).put("/user/3").send(updateData);
    
    expect(response.status).toBeWithContext(
      204,
      `Expected status 204 (No Content) when successfully updating user ID 3 with data: ${JSON.stringify(updateData)}. Check if your PUT route properly handles valid updates.`
    );
  });

  test("should verify the user was actually updated (GET /user/:id after PUT)", async () => {
    const response = await request(app).get("/user/3");
    
    expect(response.status).toBeWithContext(
      200,
      "Expected status 200 (OK) when fetching the updated user to verify changes were saved."
    );
    
    expect(response.body.username).toEqualWithContext(
      "jane.goh",
      "Expected updated user username to be 'jane.goh'. The PUT operation may not have properly saved the changes."
    );
    
    expect(response.body.email).toEqualWithContext(
      "jane.goh@example.com",
      "Expected updated user email to be 'jane.goh@example.com'. The PUT operation may not have properly saved all fields."
    );
  });
});

describe("Testing User DELETE Routes - Removing User Data", () => {
  test("should successfully delete an existing user (DELETE /user/:id)", async () => {
    const response = await request(app).delete("/user/3");
    
    expect(response.status).toBeWithContext(
      204,
      "Expected status 204 (No Content) when successfully deleting user ID 3. Check if your DELETE route properly handles user deletion and returns the correct status code."
    );
  });

  test("should return 404 when trying to access deleted user (GET /user/:id after DELETE)", async () => {
    const response = await request(app).get("/user/3");
    
    expect(response.status).toBeWithContext(
      404,
      "Expected status 404 (Not Found) when trying to fetch user ID 3 after deletion. This confirms the user was actually removed from the database. If this fails, the DELETE operation may not have worked properly."
    );
  });
});