const data = require("../data");

module.exports.getRandomDex = (req, res, next) =>
{
    // try{
    //     const number = req.params.number;
    //     const pokeDex_details = data.pokedex.find(pokeDex => data.pokedex.number == number);

    //     if(pokeDex_details == undefined){
    //         res.status(404).send("Pokedex not found");
    //     }else{
    //         res.status(200).json(pokeDex_details);
    //     }
    // }
    // catch(error){

    // }
}

module.exports.readAllPokedex = (req, res, next) =>
{
    try{
        res.status(200).json(data.pokedex)
    }
    catch(error){
        console.log("Error readAllPokedex: ", error);
        res.status(400).json(error);
    }
}

module.exports.readPokedexByNumber = (req, res, next)=>
{
    try{
        const number = Number(req.params.number)
        const details = data.pokedex.find((pokedex) => data.pokedex.number === number)

        if(details == undefined){
            res.status(404).send("Pokedex not found")
        }else{
            res.status(200).json(details)
        }
    }
    catch(error){
        console.log("Error readPokedexByNumber: ", error)
        res.status(500).json(error)
    }
}