const data = require("../data");

module.exports.readAllPokemon = (req, res, next) =>
{
    try{
        res.status(200).json(data.pokemon)
    }
    catch(error){
        console.log("Error readAllPokemon: ", error);
        res.status(400).json(error);
    }
}

module.exports.readAllPokemonWithDexInfo = (req, res, next) =>
{
    
}

module.exports.createPokemon = (req, res, next) =>
{
    
}

module.exports.readPokemonById = (req, res, next) =>
{   
    try{
        const id = req.params.id;
        const details = data.pokemon.find(pokemon => pokemon.id == id);

        if(id == undefined){
            console.log("Error readPokemonById: ", error);
            res.status(404).send("Pokemon not found");
        }else{
            res.status(200).json(details);
        }
    }
    catch(error){
        console.log("Error readPokemonById: ", error);
        res.status(500).json(error);
    }
}

module.exports.readPokemonByIdWithDexInfo = (req, res, next) =>
{   
    
}