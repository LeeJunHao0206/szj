const express = require("express");
const router = express.Router()
const pokemonRoutes = require("./pokemonRoutes")
const pokedexRoutes = require("./pokedexRoutes")
const playerRoutes = require("./playerRoutes")

router.use("/pokemon", pokemonRoutes);
router.use("/pokedex", pokedexRoutes);
router.use("/player", playerRoutes);

module.exports = router