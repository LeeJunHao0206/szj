const express = require("express")
const router = express.Router()

const controller = require("../controllers/pokemonController");

router.get('/', controller.readAllPokemon);
// router.post('/', getRandomDex, createPokemon, readPokemonById); //Advance Exercise

// router.get('/dex', readAllPokemonWithDexInfo); //Advance Exercise
router.get('/:id', controller.readPokemonById);
// router.get('/:id/dex', readPokemonByIdWithDexInfo); //Advance Exercise

module.exports = router