/**
 * Express.js API Testing Suite for Students
 * 
 * This test file validates your Express.js application's REST API endpoints.
 * Each test is designed to help you understand what went wrong and how to fix it.
 * 
 * Test Structure:
 * GET Routes - Testing data retrieval
 * POST Routes - Testing data creation  
 * PUT Routes - Testing data updates
 * DELETE Routes - Testing data deletion
 * Configuration - Testing project setup
 * 
 * How to read test failures:
 * - Look for the ❌ emoji to identify failed tests
 * - Read the detailed error messages that explain what was expected vs what happened
 * - Check the "withContext" messages for specific guidance on how to fix issues
 * 
 * Running tests: npm test
 */

const request = require("supertest");
const app = require("../src/app"); // Replace 'app' with the path to your Express.js application entry point
const fs = require("fs");

describe("Express.js GET Routes", () => {
  test("should retrieve all players (GET /player) and return initial 3 players", (done) => {
    request(app)
      .get("/player")
      .then((response) => {
        expect(response.status).toBeWithContext(
          200, 
          `Expected status 200 (OK) when fetching all players. Got ${response.status}. Check if your GET /player route is properly implemented and returns a successful response.`
        );
        
        expect(response.body.length).toBeWithContext(
          3,
          `Expected exactly 3 initial players in the database, but got ${response.body.length}. Check your initial data setup - you should have 3 players by default.`
        );

        done();
      })
  });
});

describe("Express.js POST Routes", () => {
  test("should reject player creation when no data is provided (POST /player)", (done) => {
    request(app)
      .post("/player")
      .send({})
      .then((response) => {
        expect(response.status).toBeWithContext(
          400,
          "Expected status 400 (Bad Request) when creating a player without required data. Your route should validate that name and level are provided."
        );
        done();
      })
      .catch((error) => {
        done(`Request failed: ${error.message}. Make sure your POST /player route exists and handles empty requests properly.`);
      });
  });

  test("should successfully create a new player with valid data (POST /player)", (done) => {
    const newPlayer = {
      name: "Jessie",
      level: 1,
    };
    
    request(app)
      .post("/player")
      .send(newPlayer)
      .then((response) => {
        expect(response.status).toBeWithContext(
          201,
          `Expected status 201 (Created) when creating a player with valid data: ${JSON.stringify(newPlayer)}. Check if your POST route properly handles player creation and returns the correct status code.`
        );
        done();
      })
      .catch((error) => {
        done(`Request failed: ${error.message}. Make sure your POST /player route can handle valid player data.`);
      });
  });

  test("should be able to retrieve the newly created player by ID (GET /player/4)", async () => {
    const response = await request(app).get("/player/4");
    
    expect(response.status).toBeWithContext(
      200,
      "Expected status 200 (OK) when fetching player ID 4 (the newly created player). Check if your GET /player/:id route works correctly."
    );
    
    expect(response.body.name).toEqualWithContext(
      "Jessie",
      "Expected the new player's name to be 'Jessie'. Check if your POST route properly saves the player data."
    );
    
    expect(response.body.level).toEqualWithContext(
      1,
      "Expected the new player's level to be 1. Check if your POST route properly saves all player fields."
    );
  });

  test("should have 4 total players after creating one new player (GET /player)", async () => {
    const response = await request(app).get("/player");
    
    expect(response.status).toBeWithContext(
      200,
      "Expected status 200 (OK) when fetching all players after creation."
    );
    
    expect(response.body.length).toEqualWithContext(
      4,
      "Expected 4 players total (3 initial + 1 newly created). This suggests the POST operation may not have persisted the data correctly."
    );
  });
});

describe("Express.js PUT Routes", () => {
  test("should reject update when required data is missing (PUT /player/:id)", async () => {
    const response = await request(app).put("/player/4").send({});
    
    expect(response.status).toBeWithContext(
      400,
      "Expected status 400 (Bad Request) when trying to update a player without providing name or level. Your PUT route should validate that required fields are present."
    );
    
    expect(response.body).toEqualWithContext(
      { message: "Error: name or level is undefined" },
      "Expected error message about missing name or level fields. Check if your PUT route properly validates input data."
    );
  });

  test("should return 404 when trying to update a non-existent player (PUT /player/:id)", async () => {
    const updateData = {
      name: "Super Jessie",
      level: 100,
    };
    const response = await request(app).put("/player/6").send(updateData);
    
    expect(response.status).toBeWithContext(
      404,
      "Expected status 404 (Not Found) when trying to update player ID 6 which doesn't exist. Your PUT route should check if the player exists before attempting to update."
    );
    
    expect(response.body).toEqualWithContext(
      { message: "Player not found" },
      "Expected 'Player not found' message when trying to update a non-existent player."
    );
  });

  test("should successfully update an existing player (PUT /player/:id)", async () => {
    const updateData = {
      name: "Super Ash",
      level: 100,
    };
    const response = await request(app).put("/player/1").send(updateData);
    
    expect(response.status).toBeWithContext(
      204,
      `Expected status 204 (No Content) when successfully updating player ID 1 with data: ${JSON.stringify(updateData)}. Check if your PUT route properly handles valid updates.`
    );
  });

  test("should verify the player was actually updated (GET /player/:id after PUT)", async () => {
    const response = await request(app).get("/player/1");
    
    expect(response.status).toBeWithContext(
      200,
      "Expected status 200 (OK) when fetching the updated player to verify changes were saved."
    );
    
    expect(response.body.name).toEqualWithContext(
      "Super Ash",
      "Expected updated player name to be 'Super Ash'. The PUT operation may not have properly saved the changes."
    );
    
    expect(response.body.level).toEqualWithContext(
      100,
      "Expected updated player level to be 100. The PUT operation may not have properly saved all fields."
    );
  });
});

describe("Express.js DELETE Routes", () => {
  test("should successfully delete an existing player (DELETE /player/:id)", async () => {
    const response = await request(app).delete("/player/2");
    
    expect(response.status).toBeWithContext(
      204,
      "Expected status 204 (No Content) when successfully deleting player ID 2. Check if your DELETE route properly handles player deletion and returns the correct status code."
    );
  });

  test("should return 404 when trying to access deleted player (GET /player/:id after DELETE)", async () => {
    const response = await request(app).get("/player/2");
    
    expect(response.status).toBeWithContext(
      404,
      "Expected status 404 (Not Found) when trying to fetch player ID 2 after deletion. This confirms the player was actually removed from the database. If this fails, the DELETE operation may not have worked properly."
    );
  });
});

describe("Check package.json", () => {
  let packageJson;

  beforeAll(() => {
    // Read the package.json file and parse it as JSON
    const packageJsonContents = fs.readFileSync("package.json", "utf8");
    packageJson = JSON.parse(packageJsonContents);
  });

  it("should have a 'start' script configured for production", () => {
    expect(packageJson).toHavePropertyWithContext(
      "scripts.start",
      "Missing 'start' script in package.json. Add a 'start' script in the 'scripts' section to define how to run your application in production."
    );
  });

  it("should have a 'dev' script configured for development", () => {
    expect(packageJson).toHavePropertyWithContext(
      "scripts.dev",
      "Missing 'dev' script in package.json. Add a 'dev' script in the 'scripts' section to define how to run your application in development mode (usually with nodemon for auto-restart)."
    );
  });

  it("should have correct values for start and dev scripts", () => {
    const startScript = packageJson.scripts?.start;
    const devScript = packageJson.scripts?.dev;

    expect(startScript).toEqualWithContext(
      "node index.js",
      "Expected start script to be 'node index.js'. The start script should run your main application file with Node.js."
    );
    
    expect(devScript).toEqualWithContext(
      "nodemon index.js",
      "Expected dev script to be 'nodemon index.js'. The dev script should use nodemon to automatically restart your application when files change."
    );
  });

  it("should have Express.js as a dependency", () => {
    expect(packageJson).toHavePropertyWithContext(
      "dependencies.express",
      "Missing Express.js dependency. Run 'npm install express' to add Express.js to your project dependencies. Express is required to create your web server."
    );
  });

  it("should have nodemon as a dependency for development", () => {
    expect(packageJson).toHavePropertyWithContext(
      "dependencies.nodemon",
      "Missing nodemon dependency. Run 'npm install nodemon' to add nodemon to your project dependencies. Nodemon automatically restarts your application when you make changes during development."
    );
  });
});