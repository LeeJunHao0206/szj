# Starter Repository for Assignment
You are required to build your folder structures for your project.

*Project Overview*
This system implements a full-stack web application using Node.js, Express, MySQL, and a browser-based frontend.

The system allows users to participate in challenges, complete tasks, earn points, and redeem items through a gamified interaction model. User authentication and validation are enforced to ensure secure and controlled access to system features.

The project demonstrates integration between frontend user interfaces and backend RESTful APIs, with middleware-based validation and business logic enforcement.

*Dependencies*
The project uses the following technologies and libraries:
- Node.js
- Express.js
- MySQL
- mysql2
- dotenv
- HTML, CSS, JavaScript (Frontend)
- Bootstrap (UI styling)
- Postman (Used for API testing)

Callbacks and middleware are used throughout the backend to manage validation, access control, and data flow.


Project structure:

public/
- Frontend HTML, CSS, and JavaScript files

routes/
- API route definitions

controllers/
- Request handling, validation, and middleware logic

models/
- Database queries and data access logic

configs/
- Database configuration files


Setup Instructions
1. Install all requried independencies:
- npm install express mysql2 nodemon dotenv jsonwebtoken bcrypt

2. Create a .env file in the project root directory and configure the database connection
- DB_HOST=localhost
- DB_USER=your_database_user
- DB_PASSWORD=your_database_password
- DB_NAME=your_database_name

3. Run the database initialisation script to create the required tables.
- npm run init_tables

4. Start server
- npm run dev


*Core Features*
User Management

- User registration and login
- Secure authentication using tokens
- Validation for missing data and invalid credentials
- Retrieval of user-specific information

Challenges

- Retrieve all available challenges
- Challenges include descriptions and point values
- Ownership validation for challenge-related actions
- Users can view and interact with challenges through the frontend interface

Challenge Completion and Points System

- Users can complete challenges through the website
- Completion records are stored in the database
- Users earn points upon successful completion
- Points are accumulated and tracked per user

*Gamification Features*
Item Redemption System

- Users can redeem predefined items using earned points
- Each item has a fixed point cost
- Users must have sufficient points to redeem items
- Successful redemption deducts points and records the transaction

*Error Handling*

The application uses consistent HTTP status codes:

400 Bad Request – Missing or invalid request data
401 Unauthorized – User not authenticated
403 Forbidden – Insufficient permissions or points
404 Not Found – Requested resource does not exist
409 Conflict – Duplicate resource conflicts
500 Internal Server Error – Database or server errors