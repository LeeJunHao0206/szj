//////////////////////////////////////////////////////
// REQUIRE MODULES
//////////////////////////////////////////////////////
const express = require("express");
const router = express.Router()
//////////////////////////////////////////////////////
// CREATE ROUTER
//////////////////////////////////////////////////////
const jwtMiddleware = require("../middlewares/jwtMiddleware")
const bcryptMiddleware = require("../middlewares/bcryptMiddleware")

const userController = require("../controllers/userController")

const userRoutes = require("./userRoutes")
const challengesRoutes = require("./challengesRoutes")
const petRoutes = require("./petRoutes")
const itemsRoutes = require("./itemsRoutes")
const completionRoutes = require("./completionRoutes")

router.use("/users", userRoutes);
router.use("/challenges", challengesRoutes)
router.use("/pet", petRoutes)
router.use("/items", itemsRoutes)
router.use("/completions", completionRoutes)
//////////////////////////////////////////////////////
// DEFINE ROUTES
//////////////////////////////////////////////////////
router.post("/login", userController.login, bcryptMiddleware.comparePassword, jwtMiddleware.generateToken, jwtMiddleware.sendToken);
router.post("/register", userController.checkUsernameOrEmailExist, bcryptMiddleware.hashPassword, userController.register, jwtMiddleware.generateToken, jwtMiddleware.sendToken);

router.post("/jwt/generate", jwtMiddleware.preTokenGenerate, jwtMiddleware.generateToken, jwtMiddleware.beforeSendToken, jwtMiddleware.sendToken);
router.get("/jwt/verify", jwtMiddleware.verifyToken, jwtMiddleware.showTokenVerified);
router.post("/bcrypt/compare", jwtMiddleware.preCompare, bcryptMiddleware.comparePassword, jwtMiddleware.showCompareSuccess);
router.post("/bcrypt/hash", bcryptMiddleware.hashPassword, jwtMiddleware.showHashing);

//////////////////////////////////////////////////////
// EXPORT ROUTER
//////////////////////////////////////////////////////
module.exports = router