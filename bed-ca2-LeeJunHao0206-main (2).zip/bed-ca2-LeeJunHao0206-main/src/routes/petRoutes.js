const express = require("express");
const router = express.Router()

const controller = require("../controllers/petController");
const jwtMiddleware = require("../middlewares/jwtMiddleware")

router.get('/', jwtMiddleware.verifyToken, controller.getPetsbyUserId)

router.post("/", jwtMiddleware.verifyToken, controller.countOfPets, controller.createPets)

module.exports = router;