const express = require("express");
const router = express.Router()

const controller = require("../controllers/challengesController");
const completionController = require("../controllers/completionController");
const jwtMiddleware = require("../middlewares/jwtMiddleware")

router.post('/', jwtMiddleware.verifyToken, controller.createNewChallenges)
router.post("/:challenge_id", jwtMiddleware.verifyToken, completionController.checkValidation, completionController.checkIfUserCompleted, completionController.createCompletionRecord, completionController.getPoints, completionController.incrementUserPoints, completionController.showPoints)

router.get('/', controller.getAllChallenges)
router.get("/:challenge_id", jwtMiddleware.verifyToken, completionController.getUsersbyChallengeId)

router.delete('/:challenge_id', jwtMiddleware.verifyToken, controller.checkChallengeOwner, controller.deleteChallengebyId)

router.put('/:challenge_id', jwtMiddleware.verifyToken, controller.checkChallengeOwner, controller.checkforChallengeValidation, controller.checkForCompletionRecords, controller.updateChallengeDetails)

module.exports = router;