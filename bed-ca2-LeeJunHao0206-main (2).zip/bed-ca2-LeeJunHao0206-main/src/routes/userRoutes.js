const express = require("express");
const router = express.Router()

const controller = require("../controllers/userController");
const jwtMiddleware = require("../middlewares/jwtMiddleware")

router.get('/', controller.readAllUser)
router.get('/profile', jwtMiddleware.verifyToken, controller.readUserById)

router.put("/profile", jwtMiddleware.verifyToken, controller.checkIfUserNameUsed, controller.updateUserById)

router.delete("/", jwtMiddleware.verifyToken, controller.deleteUserById)

module.exports = router;