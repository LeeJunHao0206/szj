const express = require("express");
const router = express.Router()

const controller = require("../controllers/completionController");
const jwtMiddleware = require("../middlewares/jwtMiddleware")

router.get('/', jwtMiddleware.verifyToken, controller.readChallengesByUserId)

module.exports = router;