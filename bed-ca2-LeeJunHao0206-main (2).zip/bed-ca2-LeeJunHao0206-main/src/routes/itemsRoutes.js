const express = require("express");
const router = express.Router()

const controller = require("../controllers/itemsController");
const jwtMiddleware = require("../middlewares/jwtMiddleware")

router.get("/", controller.getAllItems)
router.get("/redemptions", jwtMiddleware.verifyToken, controller.retrieveAllItemsByUserId)

router.post("/", jwtMiddleware.verifyToken, controller.checkIfItemExist, controller.getUserPoints, controller.getItemCost, controller.pointsDeduction, controller.itemRedemption)

module.exports = router;