const pool = require("../services/db")

module.exports.checkValidation = (data, callback) =>
{
    const SQL =
    `
    SELECT User.username, Wellnesschallenge.description, Wellnesschallenge.points
    FROM User, WellnessChallenge
    WHERE User.user_id = ? AND WellnessChallenge.challenge_id = ?
    ;`;
    const VALUES = [data.userId, data.challengeId]
    pool.query(SQL, VALUES, callback)
}

module.exports.createCompletionRecord = (data, callback) =>
{
    const SQL =
    `
    INSERT INTO UserCompletion (challenge_id, user_id, details, points)
    VALUES (?, ?, ?, ?)
    ;`;
    const VALUES = [data.challengeId, data.userId, data.details, data.points]
    pool.query(SQL, VALUES, callback)
}

// To check if the user exist by user_id
module.exports.checkUserExist = (data, callback) =>
{
    const SQL=
    `
    SELECT user_id FROM User
    WHERE user_id = ?
    ;`;
    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

// To retrieve the points from challenge by challenge_id
module.exports.getPoints = (data, callback) =>
{
    const SQL =`
    SELECT points FROM WellnessChallenge
    WHERE challenge_id = ?
    ;`;
    const VALUES = [data.challengeId]
    pool.query(SQL, VALUES, callback)
}

// To add the points retrieved to the user who completed the challenge
module.exports.incrementUserPoints = (data, callback) =>
{
    const SQL =
    `
    UPDATE User
    SET points = User.points + ?
    WHERE user_id = ?
    ;`;
    const VALUES = [data.points, data.userId]
    pool.query(SQL, VALUES, callback)
}

//To retrieve the points of the user after increment
module.exports.showPoints = (data, callback) =>
{
    const SQL =
    `
    SELECT points FROM User
    WHERE user_id = ?
    ;`;
    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

// To retrieve user_id and details of the challenge by challenge_id 
module.exports.getUsersbyChallengeId = (data, callback) =>
{
    const SQL =
    `
    SELECT * FROM UserCompletion
    WHERE challenge_id = ?
    ;`;
    const VALUES = [data.challengeId]
    pool.query(SQL, VALUES, callback)
}

module.exports.readChallengesByUserId = (data,  callback) =>
{
    const SQL =
    `
    SELECT completion_id, challenge_id, user_id, details, completed_at, points FROM UserCompletion
    WHERE user_id = ?
    ;`;

    const VALUES = [data.userId]

    pool.query(SQL, VALUES, callback)
}

module.exports.checkIfUserCompleted = (data, callback) =>
{
    const SQL =
    `
    SELECT * FROM UserCompletion
    WHERE user_id = ? AND challenge_id = ?
    ;`;

    const VALUES = [data.userId, data.challengeId]

    pool.query(SQL, VALUES, callback)
}