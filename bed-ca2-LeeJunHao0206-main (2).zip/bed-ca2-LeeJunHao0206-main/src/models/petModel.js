const pool = require("../services/db");

// To check if the user exist by user_id
module.exports.checkUser = (data, callback) =>
{
    const SQL = 
    `
    SELECT * FROM User
    WHERE user_id = ?
    ;`;
    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

module.exports.countOfPets = (data, callback) =>
{
    const SQL = 
    `
    SELECT COUNT(*) AS count
    FROM Pet
    WHERE user_id = ?
    ;`;
    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

// To create a new pet and ensure it is associated with user_id provided
module.exports.createPets = (data, callback) =>
{
    const SQL =
    `
    INSERT INTO Pet (user_id, pet_name, pet_type)
    VALUES (?, ?, ?)
    ;`;

    const VALUES = [data.userId, data.petName, data.petType]
    pool.query(SQL, VALUES, callback)
}

// To check if the user exist by user_id
module.exports.checkIfUserExistbyId = (data, callback) =>
{
    const SQL =
    `
    SELECT user_id FROM User
    WHERE user_id = ?
    ;`;
    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

// To retrieve all pets that were associated with the user_id provided
module.exports.getPetsbyUserId = (data, callback) =>
{
    const SQL = 
    `
    SELECT pet_name, pet_type FROM Pet
    WHERE user_id = ?
    ;`;

    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}