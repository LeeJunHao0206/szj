const pool = require("../services/db");
module.exports.selectAll = (callback) => {
  const SQLSTATMENT = `
    SELECT * FROM User;
    `;

  pool.query(SQLSTATMENT, callback);
};

module.exports.selectByuserId = (data, callback) => {
  const SQLSTATMENT = `
    SELECT * FROM User
    WHERE user_id = ?;
    `;
  const VALUES = [data.userId];

  pool.query(SQLSTATMENT, VALUES, callback);
};

module.exports.insertuserSingle = (data, callback) => {
  const SQL = `
  INSERT INTO User (username, email, password, points) 
  VALUES (?, ?, ?, 0);
  `;
  const VALUES = [data.username, data.email, data.password];
  pool.query(SQL, VALUES, callback);
};

module.exports.checkIfUserNameUsed = (data, callback) => {
  const SQLSTATEMENT = `
        SELECT * FROM User
        WHERE username = ?;
    `;
  const VALUES = [data.username];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.updateuserById = (data, callback) => {
  const SQLSTATEMENT = `
        UPDATE User
        SET username = ?
        WHERE user_id = ?;
    `;
  const VALUES = [data.username, data.userId];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.deleteuserById = (data, callback) => {
  const SQLSTATMENT = `
    DELETE FROM User
    WHERE user_id = ?;
    `;
  const VALUES = [data.userId];

  pool.query(SQLSTATMENT, VALUES, callback);
};

module.exports.checkUsernameOrEmailExist = (data, callback) => {
  const SQLSTATMENT = `
    SELECT * FROM User
    WHERE username = ? OR email = ?
    `;
  const VALUES = [data.username, data.email];

  pool.query(SQLSTATMENT, VALUES, callback);
};

module.exports.login = (data, callback) => {
  const SQL = `
    SELECT * FROM User
    WHERE username = ?
    ;`;

  const VALUES = [data.username];
  pool.query(SQL, VALUES, callback);
};
