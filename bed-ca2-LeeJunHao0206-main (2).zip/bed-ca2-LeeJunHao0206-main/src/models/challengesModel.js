const pool = require("../services/db");

// To create a new challenge
module.exports.createNewChallenges = (data, callback) => {
  const SQL = `
    INSERT INTO WellnessChallenge (creator_id, description, points)
    VALUES (?, ?, ?)
    ;`;

  const VALUES = [data.userId, data.description, data.points];
  pool.query(SQL, VALUES, callback);
};

// To retrieve all the challenges
module.exports.getAllChallenges = (callback) => {
  const SQL = `
    SELECT * from WellnessChallenge
    ;`;

  pool.query(SQL, callback);
};

module.exports.checkChallengeOwner = (data, callback) => {
  const SQL = `
        SELECT challenge_id FROM WellnessChallenge
        WHERE challenge_id = ? AND creator_id = ?;
    `;

  const VALUES = [data.challengeId, data.userId];
  pool.query(SQL, VALUES, callback);
};

// To delete challenge by challenge_id
module.exports.deleteChallengebyId = (data, callback) => {
  const SQL = `
    DELETE from WellnessChallenge
    WHERE challenge_id = ?
    ;`;

  const VALUES = [data.challengeId];
  pool.query(SQL, VALUES, callback);
};

// To check if the challenge exist by challenge_id
module.exports.checkforChallengeValidation = (data, callback) => {
  const SQL = `
    SELECT * FROM WellnessChallenge
    WHERE challenge_id = ?
    ;`;

  const VALUES = [data.challengeId];
  pool.query(SQL, VALUES, callback);
};

module.exports.checkForCompletionRecords = (data, callback) => {
  const SQL = `
    SELECT COUNT(*) AS count
    FROM UserCompletion
    WHERE challenge_id = ?
    ;`;

  const VALUES = [data.challengeId];
  pool.query(SQL, VALUES, callback);
}

// To update details of the challenge
module.exports.updateChallengeDetails = (data, callback) => {
  const SQL = `
    UPDATE wellnessChallenge
    SET description = ?, points = ?
    WHERE challenge_id = ?
    ;`;

  const VALUES = [data.description, data.points, data.challengeId];
  pool.query(SQL, VALUES, callback);
};
