const model = require("../models/userModel.js");

module.exports.readAllUser = (req, res, next) => {
  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error readAllPlayer:", error);
      res.status(500).json(error);
    } else res.status(200).json(results);
  };

  model.selectAll(callback);
};

module.exports.readUserById = (req, res, next) => {
  const data = {
    userId: res.locals.userId,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error readUserById:", error);
      res.status(500).json(error);
    } else {
      if (results.length == 0) {
        res.status(404).json({
          message: "User not found",
        });
      } else res.status(200).json(results[0]);
    }
  };

  model.selectByuserId(data, callback);
};

module.exports.createNewUser = (req, res, next) => {
  if (!req.body.username) {
    res.status(400).send("Error: username is undefined");
    return;
  }

  const data = {
    username: req.body.username, // Must match DB column
    email: req.body.email,
    password: req.body.password,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error createNewUser:", error);
      res.status(500).json(error);
    } else {
      // Assuming 'results.insertId' gives the new user's id
      res.status(201).json({
        message: "User created successfully",
        user: {
          userId: results.insertId,
          username: data.username,
          email: data.email,
          created_on: new Date(),
          updated_on: new Date(),
          last_login_on: null,
        },
      });
    }
  };

  model.insertuserSingle(data, callback);
};

module.exports.checkIfUserNameUsed = (req, res, next) => {
  if (!req.body.username) {
    res.status(400).json({
      message: "Error: username is undefined",
    });
    return;
  }

  const data = {
    username: req.body.username,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.log("Error checkIfUserNameUsed: ", error)
      return res.status(500).json({message: "Internal server error"})
    } 

    if(results.length !== 0){
      return res.status(409).json({message: "This username has been used"})
    }    
    else {
      res.locals.username = data.username;
      next();
    }
  };
  model.checkIfUserNameUsed(data, callback)
};

module.exports.updateUserById = (req, res, next) => {
  const data = {
    username: res.locals.username,
    userId: res.locals.userId,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error updateUserById:", error);
      res.status(500).json(error);
    } else {
      if (results.affectedRows === 0) {
        res.status(404).json({ message: "User not found" });
      } else {
        // 204 No Content → must not send any body
        res.status(200).json({ username: data.username });
      }
    }
  };

  model.updateuserById(data, callback);
};

module.exports.deleteUserById = (req, res, next) => {
  const data = {
    userId: res.locals.userId,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error deletePlayerById:", error);
      res.status(500).json(error);
    } else {
      if (results.affectedRows == 0) {
        res.status(404).json({
          message: "User not found",
        });
      } else res.status(204).send(); // 204 No Content
    }
  };

  model.deleteuserById(data, callback);
};

module.exports.checkUsernameOrEmailExist = (req, res, next) => {
  if (!req.body.username || !req.body.email || !req.body.password) {
    return res.status(400).json({ message: "Missing required data" });
  }

  const data = {
    username: req.body.username,
    email: req.body.email,
    password: req.body.password,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error checkUsernameOrEmailExist:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
    if (results.length > 0) {
      return res
        .status(409)
        .json({ message: "Username or email already exists" });
    } else {
      res.locals.username = data.username;
      res.locals.email = data.email;
      res.locals.password = data.password;
      next();
    }
  };
  model.checkUsernameOrEmailExist(data, callback);
};

module.exports.register = (req, res, next) => {
  const data = {
    username: res.locals.username,
    email: res.locals.email,
    password: res.locals.hash,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error register:", error);
      return res.status(500).json({ message: "Internal server error" });
    } else {
      res.locals.userId = results.insertId;
      res.locals.message = "User " + data.username + " created successfully.";
      next();
    }
  };
  model.insertuserSingle(data, callback);
};

module.exports.login = (req, res, next) => {
  if (!req.body.username || !req.body.password) {
    return res.status(400).json({ message: "Missing required data" });
  }

  const data = {
    username: req.body.username,
    password: req.body.password,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error login:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: "User not found" });
    } else {
      res.locals.username = data.username;
      res.locals.userId = results[0].user_id;
      res.locals.hash = results[0].password;
      res.locals.password = data.password;
      next();
    }
  };
  model.login(data, callback);
};
