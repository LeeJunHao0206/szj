const challengesModel = require("../models/challengesModel.js");

// To create a new challenge
module.exports.createNewChallenges = (req, res, next) => {
  if (!req.body.description || !req.body.points) {
    return res.status(400).json({ message: "Missing required data" });
  }

  const data = {
    description: req.body.description,
    userId: res.locals.userId,
    points: req.body.points,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.log("Error createNewChallenges: ", error);
      return res.status(500).json({ message: "Internal server error" });
    }

    if (10 > req.body.points || req.body.points > 100) {
      return res.status(400).json({ message: "Points can only be set up to 100 points" });
    } else {
      return res.status(201).json({
        challenge_id: results.insertId,
        description: data.description,
        creator_id: data.userId,
        points: data.points,
      });
    }
  };

  challengesModel.createNewChallenges(data, callback);
};

// To retreive all challenges
module.exports.getAllChallenges = (req, res, next) => {
  const callback = (error, results, fields) => {
    if (error) {
      console.groupCollapsed("Error getAllChallenges: ", error);
      return res.status(500).json({ message: "Internal server error" });
    }
    return res.status(200).json(results);
  };
  challengesModel.getAllChallenges(callback);
};

module.exports.checkChallengeOwner = (req, res, next) => {
  const data = {
    challengeId: req.params.challenge_id,
    userId: res.locals.userId,
  };

  const callback = (error, results) => {
    if (error) {
      return res.status(500).json({ message: "Internal server error" });
    }

    if (results.length === 0) {
      return res.status(403).json({
        message: "You are not allowed to delete this challenge",
      });
    } else {
      res.locals.challengeId = data.challengeId;
      next();
    }
  };

  challengesModel.checkChallengeOwner(data, callback);
};

// To delete challenge by challenge_id
module.exports.deleteChallengebyId = (req, res, next) => {
  const data = {
    challengeId: res.locals.challengeId,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.log("Error deleteChallengebyId: ", error);
      return res.status(500).json({ message: "Internal server error" });
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ message: "Challenge does not exist" });
    }
    return res.status(204).send();
  };
  challengesModel.deleteChallengebyId(data, callback);
};

// To check if the challenge exist
module.exports.checkforChallengeValidation = (req, res, next) => {
  const data = {
    challengeId: res.locals.challengeId,
    userId: res.locals.userId,
    description: req.body.description,
    points: req.body.points,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.log("Error checkforChallengeValidation: ", error);
      return res.status(500).json({ message: "Internal server error" });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: "Challenge does not exist " });
    }
    if (results[0].creator_id !== data.userId) {
      return res.status(403).json({ message: "Not correct owner" });
    } else {
      res.locals.description = data.description;
      res.locals.points = data.points;
      next();
    }
  };
  challengesModel.checkforChallengeValidation(data, callback);
};

module.exports.checkForCompletionRecords = (req, res, next) => {
  const data = {
    challengeId: res.locals.challengeId
  }

  const callback = (error, results, fields) =>
  {
    if (error) {
      console.log("Error checkForCompletionRecords: ", error);
      return res.status(500).json({ message: "Internal server error" });
    }
    if(results[0].count > 0){
      return res.status(409).json({message: "Challenge points cannot be modified after it has been completed by a user"})
    }

    else{
      next();
    }
  }
  challengesModel.checkForCompletionRecords(data, callback)
}

// Update the challenge that is checked by by middleware above
module.exports.updateChallengeDetails = (req, res, next) => {
  const data = {
    challengeId: res.locals.challengeId,
    description: res.locals.description,
    points: res.locals.points,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.log("Error updateChallengeDetails: ", error);
      return res.status(500).json({ message: "Internal server error" });
    }
    return res.status(200).json({
      challenge_id: data.challengeId,
      description: data.description,
      points: data.points,
    });
  };

  challengesModel.updateChallengeDetails(data, callback);
};
