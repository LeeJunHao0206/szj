const petModel = require("../models/petModel.js");

// To check if usefr exist
module.exports.checkUser = (req, res, next) =>
{
    if(!res.locals.userId){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        userId: res.locals.userId
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error checkUser: ", error)
            return res.status(500).json({message: "Internal server error"})
        }

        if(results.length === 0){
            return res.status(404).json({message: "User does not exist"})
        }
        
        else{
            next();
        }
    }
    petModel.checkUser(data, callback)
}

module.exports.countOfPets = (req, res, next) => {
    const data = {
        userId: res.locals.userId
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error countOfPets: ", error)
            return res.status(500).json({message: "Internal server error"})
        }

        if(results[0].count >= 3){
            return res.status(409).json({message: "You have hitted the limit of 3 pets per user"})
        }

        else{
            next();
        }
    }
    petModel.countOfPets(data, callback)
}

// If user exist, then create a pet with provided data
module.exports.createPets = (req, res, next) =>
{
    if(!req.body.pet_name || !req.body.pet_type){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        userId: res.locals.userId,
        petName: req.body.pet_name,
        petType: req.body.pet_type
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error createPets: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        return res.status(201).json({message: "Pet created successfully", pet_id: results.insertId})
    }
    petModel.createPets(data, callback)
}

// Check if the user exist by user_id
module.exports.checkIfUserExistbyId = (req, res, next) =>
{
    const data = {
        userId: res.locals.userId
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.error("Error checkAssociation: ", error)
            return res.status(500).json({message: "Internal server error"})
        }

        if(results.length === 0){
            return res.status(404).json({message: "User does not exist"})
        }

        else{
            next();
        }
    }
    petModel.checkIfUserExistbyId(data, callback)
}

// To retrieve all the pets associated with provided user_id
module.exports.getPetsbyUserId = (req, res, next) =>
{
    const data = {
        userId: res.locals.userId
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.error("Error getPetsbyUserId: ", error)
            return res.status(500).json(error)
        }

        if(results.length === 0){
            return res.status(404).json({message: "No pet is associated with this user"})
        }
        return res.status(200).json(results)
    }
    petModel.getPetsbyUserId(data, callback)
}