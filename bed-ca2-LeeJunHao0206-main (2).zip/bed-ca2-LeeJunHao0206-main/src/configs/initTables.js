const pool = require("../services/db");

//Added new table, pet for Gamification Design
const SQLSTATEMENT = `

DROP TABLE IF EXISTS User;

DROP TABLE IF EXISTS WellnessChallenge;

DROP TABLE IF EXISTS UserCompletion;

DROP TABLE IF EXISTS Pet;

DROP TABLE IF EXISTS PetItems;

DROP TABLE IF EXISTS ItemRedemption;

CREATE TABLE User (
user_id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(255) NOT NULL,
email VARCHAR(255) NOT NULL,
password VARCHAR(255) NOT NULL,
points INT DEFAULT 0
);

CREATE TABLE WellnessChallenge (
challenge_id INT AUTO_INCREMENT PRIMARY KEY,
creator_id INT NOT NULL,
description TEXT NOT NULL,
points INT NOT NULL
);

CREATE TABLE UserCompletion (
completion_id INT AUTO_INCREMENT PRIMARY KEY,
challenge_id INT NOT NULL,
user_id INT NOT NULL,
details TEXT,
points INT NOT NULL,
completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Pet (
pet_id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT NOT NULL,
pet_name VARCHAR(255) NOT NULL,
pet_type VARCHAR(255) NOT NULL,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE PetItems (
item_id INT AUTO_INCREMENT PRIMARY KEY,
item_name VARCHAR(100) NOT NULL,
cost INT NOT NULL
);

CREATE TABLE ItemRedemption (
redemption_id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT NOT NULL,
item_id INT NOT NULL,
redeem_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO WellnessChallenge (creator_id, description, points) VALUES
(0, 'Sleep like a boss - Get 7+ hours of sleep', 10),
(0, 'Stairs over elevator? Respect. - Take the stairs today', 20),
(0, 'Digital detox (mini edition) - No phone for 1 hour', 10),
(0, 'Touch grass IRL - Take a 15-minute walk outside', 10),
(0, 'IRL > DMs - Talk to a friend face-to-face', 20),
(0, 'Declutter your chaos - Clean your desk or room', 20),
(0, 'Help a homie - Assist someone without being asked', 20);

INSERT INTO PetItems (item_name, cost) VALUES
('Toy Ball', 30),
('Pet Food', 20),
('Grooming Kit', 40)
`;

pool.query(SQLSTATEMENT, (error, results, fields) => {
  if (error) {
    console.error("Error creating tables:", error);
  } else {
    console.log("Tables created successfully");
  }
  process.exit();
});
