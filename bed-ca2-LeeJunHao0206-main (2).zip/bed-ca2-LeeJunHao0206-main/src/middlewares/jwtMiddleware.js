//////////////////////////////////////////////////////
// REQUIRE DOTENV MODULE
//////////////////////////////////////////////////////
require("dotenv").config();
//////////////////////////////////////////////////////
// REQUIRE JWT MODULE
//////////////////////////////////////////////////////
const jwt = require("jsonwebtoken");

//////////////////////////////////////////////////////
// SET JWT CONFIGURATION
//////////////////////////////////////////////////////
const secretKey = process.env.JWT_SECRET_KEY;
const tokenDuration = process.env.JWT_EXPIRES_IN;
const tokenAlgorithm = process.env.JWT_ALGORITHM;

//////////////////////////////////////////////////////
// MIDDLEWARE FUNCTION FOR GENERATING JWT TOKEN
//////////////////////////////////////////////////////
module.exports.generateToken = (req, res, next) => {
  const payload = {
    userId: res.locals.userId,
    timestamp: new Date()
  };

  const options = {
    algorithm: tokenAlgorithm,
    expiresIn: tokenDuration,
  };

  const callback = (err, token) => {
    if (err) {
      console.error("Error jwt:", err);
      return res.status(500).json(err);
    } else {
      res.locals.token = token;
      next();
    }
  };

  const token = jwt.sign(payload, secretKey, options, callback);
};

//////////////////////////////////////////////////////
// MIDDLEWARE FUNCTION FOR SENDING JWT TOKEN
//////////////////////////////////////////////////////
module.exports.sendToken = (req, res, next) => {
  res.status(200).json({
    message: res.locals.message,
    token: res.locals.token,
    userId: res.locals.userId
  });
};

//////////////////////////////////////////////////////
// MIDDLEWARE FUNCTION FOR VERIFYING JWT TOKEN
//////////////////////////////////////////////////////
module.exports.verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const token = authHeader.substring(7);

  if (!token) {
    return res.status(401).json({ error: "No token provided" });
  }

  const callback = (err, decoded) => {
    if (err) {
      return res.status(401).json({ error: "Invalid token" });
    }

    res.locals.userId = decoded.userId;
    res.locals.tokenTimestamp = decoded.timestamp;

    next();
  };

  jwt.verify(token, secretKey, callback);
};

//////////////////////////////////////////////////////
// EXAMPLE CONTROLLER FOR TOKEN PRE-GENERATION
//////////////////////////////////////////////////////
module.exports.preTokenGenerate = (req, res, next) => {
    res.locals.userId = req.body.id;
    next();
}

//////////////////////////////////////////////////////
// EXAMPLE CONTROLLER FOR BEFORE SENDING TOKEN
//////////////////////////////////////////////////////
module.exports.beforeSendToken = (req, res, next) => {
    res.locals.message = `Token is generated.`;
    next();
}

//////////////////////////////////////////////////////
// EXAMPLE CONTROLLER FOR TOKEN VERIFICATION
//////////////////////////////////////////////////////
module.exports.showTokenVerified = (req, res, next) => {
    res.status(200).json({
        userId: res.locals.userId,
        message: "Token is verified."
    });
}

//////////////////////////////////////////////////////
// EXAMPLE CONTROLLER FOR BCRYPT COMPARE
//////////////////////////////////////////////////////
module.exports.showCompareSuccess = (req, res, next) => {
    res.status(200).json({
        message: "Compare is successful."
    });
}

//////////////////////////////////////////////////////
// EXAMPLE CONTROLLER FOR BCRYPT PRE-COMPARE
//////////////////////////////////////////////////////
module.exports.preCompare = (req, res, next) => {
    res.locals.hash = req.body.hash;
    next();
}

//////////////////////////////////////////////////////
// EXAMPLE CONTROLLER FOR BCRYPT HASHING
//////////////////////////////////////////////////////
module.exports.showHashing = (req, res, next) => {
    res.status(200).json({
        hash: res.locals.hash,
        message: `Hash is successful.`
    });
}