document.addEventListener("DOMContentLoaded", () => {
  // ===============================
  // Dynamic greeting based on time
  // ===============================
  const hour = new Date().getHours();
  let greeting = "Welcome";

  if (hour < 12) greeting = "Good morning";
  else if (hour < 18) greeting = "Good afternoon";
  else greeting = "Good evening";

  const heroTitle = document.querySelector("section h1");
  if (heroTitle) {
    heroTitle.textContent = `${greeting}, welcome to Pet Guardian`;
  }

  // ===============================
  // Navbar shadow on scroll
  // ===============================
  const navbar = document.querySelector(".navbar");
  window.addEventListener("scroll", () => {
    if (window.scrollY > 20) {
      navbar.classList.add("shadow");
    } else {
      navbar.classList.remove("shadow");
    }
  });

  // ===============================
  // Reveal elements on scroll
  // ===============================
  const revealElements = document.querySelectorAll(".card, section.bg-primary");

  const revealOnScroll = () => {
    const triggerBottom = window.innerHeight * 0.85;

    revealElements.forEach((el) => {
      const rect = el.getBoundingClientRect().top;
      if (rect < triggerBottom) {
        el.classList.add("show");
      }
    });
  };

  window.addEventListener("scroll", revealOnScroll);
  revealOnScroll(); // initial call

  // ===============================
  // CTA button interaction
  // ===============================
  const ctaButtons = document.querySelectorAll(".btn");

  ctaButtons.forEach((btn) => {
    btn.addEventListener("mouseenter", () => {
      btn.classList.add("btn-hover");
    });

    btn.addEventListener("mouseleave", () => {
      btn.classList.remove("btn-hover");
    });
  });
});
