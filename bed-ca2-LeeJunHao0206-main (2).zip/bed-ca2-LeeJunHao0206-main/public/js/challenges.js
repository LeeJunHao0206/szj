document.addEventListener("DOMContentLoaded", function () {
  const challengeList = document.getElementById("challengeList");
  const loginNotice = document.getElementById("loginNotice");
  const submitBtn = document.getElementById("submitCompletion");
  const commentInput = document.getElementById("challengeComment");

  const createForm = document.getElementById("createChallengeForm");
  const descInput = document.getElementById("newChallengeDescription");
  const pointsInput = document.getElementById("newChallengePoints");

  const commentModal = new bootstrap.Modal(
    document.getElementById("commentModal"),
  );

  // EDIT MODAL ELEMENT
  const editModal = new bootstrap.Modal(
    document.getElementById("editChallengeModal"),
  );
  const editDescInput = document.getElementById("editDescription");
  const editPointsInput = document.getElementById("editPoints");
  const saveEditBtn = document.getElementById("saveEditBtn");

  let selectedChallengeId = null;
  let editingChallengeId = null;
  let currentUserId = null;

  // AUTH CHECK
  const token = localStorage.getItem("token");

  // Show the please login advice
  if (!token && loginNotice) {
    loginNotice.classList.remove("d-none");
  }
  // Disable the create challenge button
  if (!token && createForm) {
    createForm.querySelector("button").disabled = true;
  }

  // LOAD CHALLENGES
  function loadChallenges() {
    const callback = (responseStatus, responseData) => {
      if (responseStatus !== 200) {
        alert("Failed to load challenges");
        return;
      }
      // For user to challenge (HTML)
      challengeList.innerHTML = "";

      responseData.forEach((challenge) => {
        const col = document.createElement("div");
        col.className = "col-md-4";

        const isOwner = currentUserId === challenge.creator_id;

        col.innerHTML = `
      <div class="card h-100 shadow-sm">
        <div class="card-body d-flex flex-column">
          <h5 class="card-title">Challenge ${challenge.challenge_id}</h5>
          <p class="card-text">${challenge.description}</p>
          <p class="text-muted mt-auto">Points: ${challenge.points}</p>

          <button
            class="btn btn-primary mt-2 challenge-btn"
            data-id="${challenge.challenge_id}"
            ${!token ? "disabled" : ""}
          >
            Completed
          </button>

          ${
            //To check if the user is the owner for that challenge
            isOwner
              ? `
            <div class="d-flex gap-2 mt-2">
              <button class="btn btn-warning btn-sm edit-btn"
                      data-id="${challenge.challenge_id}">
                Edit
              </button>
              <button class="btn btn-danger btn-sm delete-btn"
                      data-id="${challenge.challenge_id}">
                Delete
              </button>
            </div>
            `
              : ""
          }
        </div>
      </div>
    `;

        challengeList.appendChild(col);
      });

      attachChallengeEvents();
      attachDeleteEvents();
      attachEditEvents();
    };

    fetchMethod(currentUrl + "/api/challenges", callback, "GET", null, token);
  }

  // To load all the challenges
  if (token) {
    const callback = (responseStatus, responseData) => {
      if (responseStatus === 200) {
        currentUserId = responseData.user_id;
      }
      loadChallenges();
    };

    fetchMethod(
      currentUrl + "/api/users/profile",
      callback,
      "GET",
      null,
      token,
    );
  } else {
    loadChallenges();
  }

  // DELETE CHALLENGE
  function attachDeleteEvents() {
    document.querySelectorAll(".delete-btn").forEach((btn) => {
      btn.onclick = () => {
        // To define challengeId
        const id = btn.dataset.id;
        if (!confirm("Are you sure you want to delete this challenge?")) return;

        const challengesDeletion = (responseStatus, responseData) => {
          if (responseStatus === 204) {
            alert("Challenge deleted");
            location.reload();
          } else {
            alert("Delete failed");
          }
        };

        fetchMethod(
          currentUrl + "/api/challenges/" + id,
          challengesDeletion,
          "DELETE",
          null,
          token,
        );
      };
    });
  }

  // EDIT CHALLENGE (CLICK)
  function attachEditEvents() {
    document.querySelectorAll(".edit-btn").forEach((btn) => {
      btn.onclick = () => {
        editingChallengeId = btn.dataset.id;

        const card = btn.closest(".card-body");
        editDescInput.value = card.querySelector(".card-text").textContent;
        editPointsInput.value = card
          .querySelector(".text-muted")
          .textContent.replace("Points:", "")
          .trim();

        editModal.show();
      };
    });
  }

  // EDIT CHALLENGE (SAVE)
  saveEditBtn.onclick = () => {
    const description = editDescInput.value.trim();
    const points = editPointsInput.value;

    if (!description || !points) {
      alert("All fields required");
      return;
    }

    const callback = (responseStatus, responseData) => {
      if (responseStatus === 200) {
        alert("Challenge updated");
        editModal.hide();
        location.reload();
      } else if (responseStatus === 409) {
        alert(
          "You are not allowed to modify the challenge as there is a completion record",
        );
        editPointsInput.disabled = true;
      } else {
        alert("Update failed");
        location.reload();
      }
    };

    fetchMethod(
      currentUrl + "/api/challenges/" + editingChallengeId,
      callback,
      "PUT",
      { description, points },
      token,
    );
  };

  // COMPLETE CHALLENGE
  function attachChallengeEvents() {
    document.querySelectorAll(".challenge-btn").forEach((btn) => {
      btn.onclick = () => {
        selectedChallengeId = btn.dataset.id;
        commentInput.value = "";
        commentModal.show();
      };
    });
  }

  submitBtn.onclick = (e) => {
    e.preventDefault();

    const details = commentInput.value.trim();
    if (!details) return alert("Enter a comment");

    const handleChallengeCompletionResponse = (responseStatus) => {
      if (responseStatus === 200 || responseStatus === 201) {
        commentModal.hide();
        location.reload();
      } else {
        alert("Completion failed");
      }
    };
    fetchMethod(
      currentUrl + "/api/challenges/" + selectedChallengeId,
      handleChallengeCompletionResponse,
      "POST",
      { details },
      token,
    );
  };

  // CREATE CHALLENGE
  if (createForm) {
    createForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const description = descInput.value.trim();
      const points = pointsInput.value;

      if (!description || !points) {
        return alert("All fields required");
      }

      if (10 > points || points > 100) {
        return alert("Points can only be set in the range of 10 to 100 points");
      }

      const handleCreateChallengeResponse = (responseStatus) => {
        if (responseStatus === 200 || responseStatus === 201) {
          alert("Challenge created");
          location.reload();
        } else {
          alert("Create failed");
        }
      };
      fetchMethod(
        currentUrl + "/api/challenges",
        handleCreateChallengeResponse,
        "POST",
        { description, points },
        token,
      );
    });
  }

  // REFRESH USER POINTS
  function refreshUserPoints() {
    const pointsNavItem = document.getElementById("pointsNavItem");
    const pointsDisplay = document.getElementById("pointsDisplay");

    const handleUserPointsResponse = (responseStatus, responseData) => {
      if (responseStatus === 200) {
        pointsDisplay.textContent = `Points: ${responseData.points}`;
        pointsNavItem.classList.remove("d-none");
      } else {
        pointsNavItem.classList.add("d-none");
      }
    };
    fetchMethod(
      currentUrl + "/api/users/profile",
      handleUserPointsResponse,
      "GET",
      null,
      token,
    );
  }

  refreshUserPoints();
});
