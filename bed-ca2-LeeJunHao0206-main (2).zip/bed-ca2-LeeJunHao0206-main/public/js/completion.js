document.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("token");

  const loginNotice = document.getElementById("loginNotice");
  const tableContainer = document.getElementById("tableContainer");
  const tableBody = document.getElementById("completionTableBody");

  // AUTH CHECK
  if (!token) {
    loginNotice.classList.remove("d-none");
    return;
  }
  // FETCH COMPLETIONS
  const callback = (responseStatus, responseData) => {
    tableBody.innerHTML = "";

    // Not logged in
    if (responseStatus === 401 || responseStatus === 403) {
      loginNotice.classList.remove("d-none");
      tableContainer.classList.add("d-none");
      return;
    }

    // Logged in but no completion records
    if (responseStatus === 404 || responseData.length === 0) {
      loginNotice.classList.add("d-none");
      tableContainer.classList.remove("d-none");

      tableBody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center text-muted">
          You have not completed any challenges yet.
        </td>
      </tr>
    `;
      return;
    }

    // Other errors
    if (responseStatus !== 200) {
      console.error(responseData);
      alert("Failed to load completion records");
      return;
    }

    // Normal case
    loginNotice.classList.add("d-none");
    tableContainer.classList.remove("d-none");

    responseData.forEach((item, index) => {
      const row = document.createElement("tr");

      row.innerHTML = `
      <td>${index + 1}</td>
      <td>${item.challenge_id}</td>
      <td>${item.user_id}</td>
      <td>${item.details}</td>
      <td>${item.completed_at}</td>
      <td>${item.points}</td>
    `;

      tableBody.appendChild(row);
    });
  };

  fetchMethod(
    currentUrl + "/api/completions/",
    callback,
    "GET",
    null,
    localStorage.getItem("token"),
  );

  function refreshUserPoints() {
    const pointsNavItem = document.getElementById("pointsNavItem");
    const pointsDisplay = document.getElementById("pointsDisplay");

    const callback = (responseStatus, responseData) => {
      if (responseStatus === 200) {
        pointsDisplay.textContent = `Points: ${responseData.points}`;
        pointsNavItem.classList.remove("d-none");
      } else {
        pointsNavItem.classList.add("d-none");
      }
    };

    fetchMethod(
      currentUrl + "/api/users/profile",
      callback,
      "GET",
      null,
      localStorage.getItem("token"),
    );
  }

  // Call it ONCE when page loads
  refreshUserPoints();
});

document.getElementById("searchBtn").onclick = () => {
  const challengeId = document.getElementById("searchChallengeId").value.trim();
  const tableBody = document.getElementById("completionTableBody");

  if (!challengeId) {
    location.reload();
  }

  const callback = (status, data) => {
    if (status === 200) {
      tableBody.innerHTML = "";

      data.forEach((item, index) => {
        const row = document.createElement("tr");

        row.innerHTML = `
        <td>${index + 1}</td>
        <td>${item.challenge_id}</td>
        <td>${item.user_id}</td>
        <td>${item.details}</td>
        <td>${item.completed_at}</td>
        <td>${item.points}</td>
      `;

        tableBody.appendChild(row);
      });
    } else if (status === 404) {
      tableBody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center text-muted">
          No users have completed this challenge.
        </td>
      </tr>
    `;
    } else {
      alert("Failed to search completion records");
    }
  };

  fetchMethod(
    currentUrl + "/api/challenges/" + challengeId,
    callback,
    "GET",
    null,
    localStorage.getItem("token"),
  );
};
