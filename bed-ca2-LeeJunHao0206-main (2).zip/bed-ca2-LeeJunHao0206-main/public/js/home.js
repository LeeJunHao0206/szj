document.addEventListener("DOMContentLoaded", function () {
  const token = localStorage.getItem("token");

  // Guard: only logged-in users allowed
  if (!token) {
    window.location.href = "index.html";
    return;
  }

  // Logout logic
  const logoutBtn = document.getElementById("logoutButton");
  logoutBtn.addEventListener("click", function () {
    localStorage.removeItem("token");
    window.location.href = "index.html";
  });

  function refreshUserPoints() {
    const pointsNavItem = document.getElementById("pointsNavItem");
    const pointsDisplay = document.getElementById("pointsDisplay");

    const callback = (responseStatus, responseData) => {
      if (responseStatus === 200) {
        pointsDisplay.textContent = `Points: ${responseData.points}`;
        pointsNavItem.classList.remove("d-none");
      } else {
        pointsNavItem.classList.add("d-none");
      }
    };

    fetchMethod(
      currentUrl + "/api/users/profile",
      callback,
      "GET",
      null,
      token
    );
  }

  // Call it ONCE when page loads
  refreshUserPoints();

  // ===============================
// Fetch all users (admin-style overview)
// ===============================
function loadAllUsers() {
  const usersTableBody = document.getElementById("usersTableBody");

  const callback = (responseStatus, responseData) => {
    if (responseStatus === 200) {
      usersTableBody.innerHTML = "";

      responseData.forEach((user) => {
        const row = document.createElement("tr");

        row.innerHTML = `
          <td>${user.user_id}</td>
          <td>${user.username}</td>
          <td>${user.points}</td>
        `;

        usersTableBody.appendChild(row);
      });
    } else {
      usersTableBody.innerHTML = `
        <tr>
          <td colspan="4" class="text-danger">Unable to load users</td>
        </tr>
      `;
    }
  };

  fetchMethod(
    currentUrl + "/api/users",
    callback,
    "GET",
    null,
    token
  );
}

// Call once when page loads
loadAllUsers();
});
