document.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("token");

  const createPetForm = document.getElementById("createPetForm");
  const loginNotice = document.getElementById("loginNotice");
  const petList = document.getElementById("petList");

  // AUTH CHECK
  if (!token) {
    loginNotice.classList.remove("d-none");
    if (createPetForm) {
      createPetForm.querySelector("button").disabled = true;
    }
    return;
  }
  // FETCH USER PETS (JWT-BASED)
  const callback = (responseStatus, responseData) => {
    // 401 / 403 = not logged in or token invalid
    if (responseStatus === 401 || responseStatus === 403) {
      console.error("Unauthorized");
      loginNotice.classList.remove("d-none");
      return;
    }

    // 404 = logged in but no pets
    if (responseStatus === 404) {
      petList.innerHTML = `
      <div class="col-12 text-center text-muted">
        You do not own any pets yet.
      </div>
    `;
      return;
    }

    // other errors
    if (responseStatus !== 200) {
      console.error(responseData);
      loginNotice.classList.remove("d-none");
      return;
    }

    // success (200)
    petList.innerHTML = "";

    if (responseData.length === 0) {
      petList.innerHTML = `
      <div class="col-12 text-center text-muted">
        You do not own any pets yet.
      </div>
    `;
      return;
    }

    responseData.forEach((pet) => {
      const col = document.createElement("div");
      col.className = "col-md-4";

      col.innerHTML = `
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title">${pet.pet_name}</h5>
          <p class="card-text">
            <strong>Type:</strong> ${pet.pet_type}<br />
          </p>
        </div>
      </div>
    `;

      petList.appendChild(col);
    });
  };

  fetchMethod(
    currentUrl + "/api/pet/",
    callback,
    "GET",
    null,
    localStorage.getItem("token"),
  );

  // CREATE PET
  if (createPetForm) {
    createPetForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const token = localStorage.getItem("token");
      const petName = document.getElementById("petName").value.trim();
      const petType = document.getElementById("petType").value.trim();

      if (!token) {
        alert("Please log in first.");
        return;
      }

      if (!petName || !petType) {
        alert("Pet name and pet type are required.");
        return;
      }

      const callback = (responseStatus, responseData) => {
        if (responseStatus === 201 || responseStatus === 200) {
          createPetForm.reset();
          location.reload();
        } else if (responseStatus === 409) {
          alert(responseData.message);
          location.reload();
        } else {
          console.error(responseData);
          alert("Unable to create pet.");
        }
      };

      fetchMethod(
        currentUrl + "/api/pet",
        callback,
        "POST",
        {
          pet_name: petName,
          pet_type: petType,
        },
        token,
      );
    });
  }
  function refreshUserPoints() {
    const pointsNavItem = document.getElementById("pointsNavItem");
    const pointsDisplay = document.getElementById("pointsDisplay");

    const callback = (responseStatus, responseData) => {
      if (responseStatus === 200) {
        pointsDisplay.textContent = `Points: ${responseData.points}`;
        pointsNavItem.classList.remove("d-none");
      } else {
        pointsNavItem.classList.add("d-none");
      }
    };

    fetchMethod(
      currentUrl + "/api/users/profile",
      callback,
      "GET",
      null,
      token,
    );
  }

  //Call it ONCE when page loads
  refreshUserPoints();
});
