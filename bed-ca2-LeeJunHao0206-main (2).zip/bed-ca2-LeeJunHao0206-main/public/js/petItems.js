document.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("token");

  const loginNotice = document.getElementById("loginNotice");
  const itemList = document.getElementById("itemList");

  // SHOW LOGIN NOTICE (NO BLOCK)
  if (!token) {
    loginNotice.classList.remove("d-none");
  }

  // FETCH PET ITEMS (PUBLIC)
  const loadItems = () => {
    const callback = (status, data) => {
      if (status === 404) {
        itemList.innerHTML = `
          <div class="col-12 text-center text-muted">
            No pet items available.
          </div>
        `;
        return;
      }

      if (status !== 200) {
        console.error("Failed to load items:", data);
        return;
      }

      itemList.innerHTML = "";

      data.forEach((item) => {
        const col = document.createElement("div");
        col.className = "col-md-4";

        col.innerHTML = `
          <div class="card shadow-sm h-100">
            <div class="card-body">
              <h5 class="card-title">${item.item_name}</h5>
              <p class="card-text">
                <strong>Cost:</strong> ${item.cost} points
              </p>
              <button
                class="btn btn-primary w-100 redeem-btn"
                ${!token ? "disabled" : ""}
              >
                Redeem
              </button>
            </div>
          </div>
        `;

        // Only attach click if logged in
        if (token) {
          col.querySelector(".redeem-btn").addEventListener("click", () => {
            redeemItem(item.item_id);
          });
        }

        itemList.appendChild(col);
      });
    };

    // PUBLIC request – no token
    fetchMethod(currentUrl + "/api/items", callback, "GET");
  };

  // REDEEM ITEM (AUTH REQUIRED)
  const redeemItem = (itemId) => {
    const callback = (status, data) => {
      if (status === 200 || status === 201) {
        alert("Item redeemed successfully!");
        refreshUserPoints();
      } else {
        alert("Not enough points or redeem failed.");
      }
    };

    fetchMethod(
      currentUrl + "/api/items",
      callback,
      "POST",
      { item_id: itemId },
      token,
    );
  };

  // REFRESH USER POINTS
  const refreshUserPoints = () => {
    function handleUserPointsResponse(status, data) {
      const pointsNavItem = document.getElementById("pointsNavItem");
      const pointsDisplay = document.getElementById("pointsDisplay");

      if (status === 200) {
        pointsDisplay.textContent = `Points: ${data.points}`;
        pointsNavItem.classList.remove("d-none");
      } else {
        pointsNavItem.classList.add("d-none");
      }
    }

    fetchMethod(
      currentUrl + "/api/users/profile",
      handleUserPointsResponse,
      "GET",
      null,
      token,
    );
  };

  // INIT
  loadItems();

  if (token) {
    refreshUserPoints();
  }
});
