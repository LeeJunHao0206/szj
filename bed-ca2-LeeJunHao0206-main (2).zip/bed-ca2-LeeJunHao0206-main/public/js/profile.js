document.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("token");

  const loginNotice = document.getElementById("loginNotice");
  const profileCard = document.getElementById("profileCard");

  const usernameEl = document.getElementById("username");
  const emailEl = document.getElementById("email");
  const pointsEl = document.getElementById("points");

  // AUTH CHECK
  if (!token) {
    loginNotice.classList.remove("d-none");
    return;
  }

  // FETCH USER PROFILE
  fetchMethod(
    currentUrl + "/api/users/profile",
    (responseStatus, responseData) => {
      if (responseStatus === 200) {
        profileCard.classList.remove("d-none");
        usernameEl.textContent = responseData.username;
        emailEl.textContent = responseData.email;
        pointsEl.textContent = responseData.points;
      } else {
        loginNotice.classList.remove("d-none");
      }
    },
    "GET",
    null,
    token,
  );

  // UPDATE USERNAME
  const updateForm = document.getElementById("updateUsernameForm");
  const newUsernameInput = document.getElementById("newUsername");
  const updateMessage = document.getElementById("updateMessage");

  updateForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const newUsername = newUsernameInput.value.trim();
    if (!newUsername) return;

    const callback = (responseStatus, responseData) => {
      if (responseStatus === 200) {
        usernameEl.textContent = responseData.username;
        updateMessage.textContent = "Username updated successfully";
        updateMessage.className = "alert alert-success mt-3";
        updateMessage.classList.remove("d-none");
        newUsernameInput.value = "";
        return;
      }

      if (responseStatus === 409) {
        updateMessage.textContent =
          "Username already exists. Please choose another.";
        updateMessage.className = "alert alert-warning mt-3";
        updateMessage.classList.remove("d-none");
        return;
      }

      if (responseStatus === 400) {
        updateMessage.textContent = "Invalid username.";
        updateMessage.className = "alert alert-danger mt-3";
        updateMessage.classList.remove("d-none");
        return;
      }

      if (responseStatus === 401 || responseStatus === 403) {
        updateMessage.textContent = "Please log in again.";
        updateMessage.className = "alert alert-danger mt-3";
        updateMessage.classList.remove("d-none");
        return;
      }

      updateMessage.textContent = "Failed to update username.";
      updateMessage.className = "alert alert-danger mt-3";
      updateMessage.classList.remove("d-none");
    };

    // SEND PUT REQUEST
    fetchMethod(
      currentUrl + "/api/users/profile",
      callback,
      "PUT",
      { username: newUsername },
      token,
    );
  });

  // LOAD REDEEMED ITEMS
  function loadRedeemedItems() {
    const redeemedItemsTable = document.getElementById("redeemedItemsTable");
    const redeemedItemsBody = document.getElementById("redeemedItemsBody");
    const noRedeemedItems = document.getElementById("noRedeemedItems");

    const callback = (responseStatus, responseData) => {
      redeemedItemsBody.innerHTML = "";

      if (responseStatus === 401 || responseStatus === 403) {
        redeemedItemsTable.classList.add("d-none");
        noRedeemedItems.classList.remove("d-none");
        return;
      }

      if (responseStatus === 404 || responseData.length === 0) {
        redeemedItemsTable.classList.add("d-none");
        noRedeemedItems.classList.remove("d-none");
        return;
      }

      if (responseStatus !== 200) {
        redeemedItemsTable.classList.add("d-none");
        noRedeemedItems.classList.remove("d-none");
        return;
      }

      responseData.forEach((item) => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${item.item_name}</td>
          <td>${item.redeem_at}</td>
        `;
        redeemedItemsBody.appendChild(row);
      });

      noRedeemedItems.classList.add("d-none");
      redeemedItemsTable.classList.remove("d-none");
    };

    fetchMethod(
      currentUrl + "/api/items/redemptions",
      callback,
      "GET",
      null,
      token,
    );
  }

  loadRedeemedItems();

  // DELETE USER ACCOUNT
  const deleteBtn = document.getElementById("deleteAccountBtn");
  const deleteMessage = document.getElementById("deleteMessage");

  deleteBtn.addEventListener("click", () => {
    const confirmDelete = confirm(
      "Are you sure? This action cannot be undone.",
    );

    if (!confirmDelete) return;

    const callback = (responseStatus, responseData) => {
      if (responseStatus === 200 || responseStatus === 204) {
        deleteMessage.textContent = "Account deleted successfully.";
        deleteMessage.className = "alert alert-success mt-3";
        deleteMessage.classList.remove("d-none");

        // clear token and redirect
        localStorage.removeItem("token");
        setTimeout(() => {
          window.location.href = "login.html";
        }, 1500);

        return;
      }

      if (responseStatus === 401 || responseStatus === 403) {
        deleteMessage.textContent = "Please log in again.";
        deleteMessage.className = "alert alert-danger mt-3";
        deleteMessage.classList.remove("d-none");
        return;
      }

      deleteMessage.textContent = "Failed to delete account.";
      deleteMessage.className = "alert alert-danger mt-3";
      deleteMessage.classList.remove("d-none");
    };

    fetchMethod(currentUrl + "/api/users", callback, "DELETE", null, token);
  });
});
