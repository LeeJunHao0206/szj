const pool = require('../services/db');
module.exports.selectAll = (callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM User;
    `;

pool.query(SQLSTATMENT, callback);
}

module.exports.selectByuserId = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM User
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.insertuserSingle = (data, callback) => {
    const SQL = `INSERT INTO User (username, email, password) VALUES (?, ?, ?);`;
    const VALUES = [data.username, data.email, data.password];
    pool.query(SQL, VALUES, callback);
}

module.exports.updateuserById = (data, callback) => {
    const SQLSTATEMENT = `
        UPDATE User
        SET username = ?, email = ?, password = ?
        WHERE id = ?;
    `;
    const VALUES = [data.username, data.email, data.password, data.id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.deleteuserById = (data, callback) =>
{
    const SQLSTATMENT = `
    DELETE FROM User
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.checkUsernameOrEmailExist = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM User
    WHERE username = ? OR email = ?
    `;
const VALUES = [data.username, data.email];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.login = (data, callback) =>
{
    const SQL =
    `
    SELECT * FROM User
    WHERE username = ?
    ;`;

    const VALUES = [data.username]
    pool.query(SQL, VALUES, callback)
}

module.exports.createNewPlayer = (data, callback) => {
    const SQL = `
    INSERT INTO Player (name, level) 
    VALUES (?, 1);`;
    const VALUES = [data.name];
    pool.query(SQL, VALUES, callback);
}

module.exports.updatePlayeruserrel = (data, callback) =>
{
    const SQL = `
    INSERT INTO PlayerUserRel (user_id, player_id) 
    VALUES (?, ?);`;
    const VALUES = [data.userId, data.playerId];
    pool.query(SQL, VALUES, callback);
}

module.exports.sendUserInfo = (data, callback) =>
{
    const SQL =`
    SELECT * FROM Player
    WHERE id = ?
    ;`;
    const VALUES = [data.playerId]
    pool.query(SQL, VALUES, callback)
}

module.exports.updatePlayer = (data, callback) =>
{
    const SQL =`
    UPDATE Player
    SET name = ?
    WHERE id = ?
    ;`;
    const VALUES = [data.name, data.playerId]
    pool.query(SQL, VALUES, callback)
}

module.exports.deletePlayer = (data, callback) =>
{
    const SQL =`
    DELETE FROM Player
    WHERE id = ?
    ;`;
    const VALUES = [data.playerId]
    pool.query(SQL, VALUES, callback)
}

module.exports.createNewPokemon = (data, callback) =>
{
    const SQL =`
    INSERT INTO Pokemon (owner_id, dex_num, hp, atk, def)
    VALUES (?, ?, ?, ?, ?)
    ;`;
    const VALUES = [data.userId, data.dex_num, data.hp, data.atk, data.def]
    pool.query(SQL, VALUES, callback)
}

module.exports.showPokemonData = (data, callback) =>
{
    const SQL =`
    SELECT * FROM Pokemon
    WHERE id = ?
    ;`;
    const VALUES = [data.pokemonId]
    pool.query(SQL, VALUES, callback)
}