const pool = require('../services/db');

module.exports.selectRandomDex = (callback) => //
{
    const SQLSTATMENT = `
    SELECT * FROM pokedex
    WHERE number = ? 
    RAND()
    LIIMIT 1;
    `;

const VALUES = [data.number]

pool.query(SQLSTATMENT, callback);
}

module.exports.selectAll = (callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM pokedex;
    `;

pool.query(SQLSTATMENT, callback);
}