/**
 * 🧪 Database Model Testing Suite for Students
 * 
 * This test file validates your database model functions (CRUD operations).
 * Each test is designed to help you understand what went wrong and how to fix it.
 * 
 * Test Structure:
 * 🔍 Database CRUD Operations - Testing actual database interactions
 * 🔧 Model Implementation Tests - Testing SQL query construction
 * 
 * How to read test failures:
 * - Look for the ❌ emoji to identify failed tests
 * - Read the detailed error messages that explain what was expected vs what happened
 * - Check the context messages for specific guidance on how to fix issues
 * 
 * Running tests: npm test
 */

const model = require("../src/models/playerModel");
const pool = require("../src/services/db");

// Global test configuration
jest.setTimeout(10000); // 10 second timeout for all tests

describe("🔍 Testing Database CRUD Operations - Real Database Interactions", () => {
  // Add timeout and error handling for each test
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("should retrieve player data by ID using selectById method", (done) => {
    const mockData = {
      id: 1,
    };

    const mockCallback = (error, results) => {
      try {
        expect(error).toBeWithContext(
          null,
          "Expected no database error when selecting player by ID. Check if your database connection is working and the Player table exists with data."
        );
        
        expect(results).toEqualWithContext(
          expect.any(Array),
          "Expected selectById to return an array of player records (MySQL2 returns arrays). Check if your selectById function properly queries the database and returns the player data."
        );
        
        // Additional assertions on the result can be added here
        done();
      } catch (testError) {
        done(testError);
      }
    };

    try {
      model.selectById(mockData, mockCallback);
    } catch (error) {
      done(new Error(`❌ Failed to execute selectById: ${error.message}. Check if the function exists and is properly implemented.`));
    }
  });

  test("should retrieve all player data using selectAll method", (done) => {
    const mockCallback = (error, results) => {
      try {
        expect(error).toBeWithContext(
          null,
          "Expected no database error when selecting all players. Check if your database connection is working and the Player table exists."
        );
        
        expect(results).toEqualWithContext(
          expect.any(Array),
          "Expected selectAll to return an array of player records. Check if your selectAll function properly queries the database."
        );
        
        if (results && results.length >= 3) {
          expect(results[0].name).toEqualWithContext(
            "Ash",
            "Expected first player's name to be 'Ash'. Check if your initial database setup created the correct test data."
          );
          
          expect(results[1].id).toEqualWithContext(
            2,
            "Expected second player's ID to be 2. Check if your initial database setup created the correct test data with proper IDs."
          );
          
          expect(results[2].level).toEqualWithContext(
            30,
            "Expected third player's level to be 30. Check if your initial database setup created the correct test data."
          );
        }
        
        done();
      } catch (testError) {
        done(testError);
      }
    };
    
    try {
      model.selectAll(mockCallback);
    } catch (error) {
      done(new Error(`❌ Failed to execute selectAll: ${error.message}. Check if the function exists and is properly implemented.`));
    }
  });

  test("should insert a new player into the database using insertSingle method", (done) => {
    const mockData = {
      name: "Jessie",
      level: 1,
    };

    const mockCallback = (error, results) => {
      try {
        expect(error).toBeWithContext(
          null,
          "Expected no database error when inserting a new player. Check if your database connection is working and the insertSingle function is implemented correctly."
        );
        
        expect(results).toEqualWithContext(
          expect.any(Object),
          "Expected insertSingle to return a result object. Check if your insertSingle function properly executes the INSERT query."
        );
        
        if (results && results.affectedRows !== undefined) {
          expect(results.affectedRows).toEqualWithContext(
            1,
            "Expected exactly 1 row to be affected when inserting a new player. Check if your INSERT query is working properly."
          );
        }
        
        done();
      } catch (testError) {
        done(testError);
      }
    };
    
    try {
      model.insertSingle(mockData, mockCallback);
    } catch (error) {
      done(new Error(`❌ Failed to execute insertSingle: ${error.message}. Check if the function exists and is properly implemented.`));
    }
  });

  test("should update player data by ID using updateById method", (done) => {
    const mockData = {
      id: 1,
      name: "Super Ash",
      level: 100
    };

    const mockCallback = (error, results) => {
      try {
        expect(error).toBeWithContext(
          null,
          "Expected no database error when updating a player. Check if your database connection is working and the updateById function is implemented correctly."
        );
        
        expect(results).toEqualWithContext(
          expect.any(Object),
          "Expected updateById to return a result object. Check if your updateById function properly executes the UPDATE query."
        );
        
        console.log("Update results:", results);
        
        // Note: Commented out because different MySQL drivers might return different result structures
        // if (results && results.affectedRows !== undefined) {
        //   expect(results.affectedRows).toEqualWithContext(
        //     1,
        //     "Expected exactly 1 row to be affected when updating a player. Check if the player ID exists and your UPDATE query is working properly."
        //   );
        // }
        
        done();
      } catch (testError) {
        done(testError);
      }
    };
    
    try {
      model.updateById(mockData, mockCallback);
    } catch (error) {
      done(new Error(`❌ Failed to execute updateById: ${error.message}. Check if the function exists and is properly implemented.`));
    }
  });

  test("should delete player data by ID using deleteById method", (done) => {
    const mockData = {
      id: 3
    };

    const mockCallback = (error, results) => {
      try {
        expect(error).toBeWithContext(
          null,
          "Expected no database error when deleting a player. Check if your database connection is working and the deleteById function is implemented correctly."
        );
        
        expect(results).toEqualWithContext(
          expect.any(Object),
          "Expected deleteById to return a result object with affectedRows. Check if your deleteById function properly executes the DELETE query."
        );
        
        console.log("Delete results:", results);
        
        // Note: Commented out because different MySQL drivers might return different result structures
        // if (results && results[0] && results[0].affectedRows !== undefined) {
        //   expect(results[0].affectedRows).toEqualWithContext(
        //     1,
        //     "Expected exactly 1 row to be affected when deleting a player. Check if the player ID exists and your DELETE query is working properly."
        //   );
        // }
        
        done();
      } catch (testError) {
        done(testError);
      }
    };
    
    try {
      model.deleteById(mockData, mockCallback);
    } catch (error) {
      done(new Error(`❌ Failed to execute deleteById: ${error.message}. Check if the function exists and is properly implemented.`));
    }
  });
});

describe("🔧 Testing Model Implementation - SQL Query Construction and Database Calls", () => {
  test("selectAll should call pool.query", () => {
    const mockCallback = () => {};
    let querySpy;

    try {
      querySpy = jest.spyOn(pool, "query");
      model.selectAll(mockCallback);

      // First check that pool.query was actually called
      expect(querySpy).toHaveBeenCalled();

      expect(querySpy).toHaveBeenCalledWith(
        expect.stringContaining("SELECT * FROM Player"),
        mockCallback
      );

      // Additional validation with proper Jest assertions
      if (querySpy.mock.calls.length > 0) {
        const calledQuery = querySpy.mock.calls[0][0];
        expect(calledQuery).toContainSQLPatternDynamic(
          "SELECT * FROM Player",
          {
            operation: "selectAll query",
            field: "SELECT statement",
            suggestions: [
              "Make sure to use 'SELECT * FROM Player' to fetch all columns",
              "Check if your selectAll function constructs the correct SQL query",
              "Verify the table name is 'Player' (case-sensitive)"
            ]
          }
        );
      }
    } catch (error) {
      throw new Error(`❌ Test execution failed: ${error.message}

🔧 Check:
   - playerModel.js selectAll function exists and is properly defined
   - Database connection is working
   - No syntax errors in your SQL query`);
    } finally {
      // Always restore the spy to prevent test pollution
      if (querySpy) {
        querySpy.mockRestore();
      }
    }
  });

  test("selectById should call pool.query", () => {
    const mockData = { id: 1 };
    const mockCallback = () => {};
    let querySpy;

    try {
      querySpy = jest.spyOn(pool, "query");
      model.selectById(mockData, mockCallback);

      // First check that pool.query was actually called
      expect(querySpy).toHaveBeenCalled();

      // Check if the query contains the expected SQL parts
      if (querySpy.mock.calls.length > 0) {
        const calledQuery = querySpy.mock.calls[0][0];
        const calledParams = querySpy.mock.calls[0][1];

        expect(calledQuery).toContainSQLPatternDynamic(
          "SELECT * FROM Player",
          {
            operation: "selectById query",
            field: "SELECT statement",
            suggestions: [
              "Make sure to use 'SELECT * FROM Player' to fetch all columns",
              "Check if your selectById function starts with the correct SELECT statement",
              "Verify the table name is 'Player' (case-sensitive)"
            ]
          }
        );

        expect(calledQuery).toContainSQLPatternDynamic(
          "WHERE id = ?",
          {
            operation: "selectById query",
            field: "WHERE clause",
            suggestions: [
              "Include 'WHERE id = ?' to filter by the specific player ID",
              "Make sure to use a parameter placeholder (?) for the ID value",
              "Check if your selectById function includes the correct WHERE clause"
            ]
          }
        );

        expect(calledParams).toEqualWithContext(
          [1],
          "Expected selectById to pass [1] as query parameters. Check if your selectById function correctly passes the ID parameter to the database query."
        );
      }
    } catch (error) {
      throw new Error(`❌ Test execution failed: ${error.message}

🔧 Check:
   - playerModel.js selectById function exists and is properly defined
   - Database connection is working
   - No syntax errors in your SQL query`);
    } finally {
      // Always restore the spy to prevent test pollution
      if (querySpy) {
        querySpy.mockRestore();
      }
    }
  });

  test("insertSingle should call pool.query", () => {
    const mockData = { 
      name: "Jessie",
      level: 1 
    };
    const mockCallback = () => {};
    let querySpy;

    try {
      querySpy = jest.spyOn(pool, "query");
      model.insertSingle(mockData, mockCallback);

      // First check that pool.query was actually called
      expect(querySpy).toHaveBeenCalled();

      if (querySpy.mock.calls.length > 0) {
        const calledQuery = querySpy.mock.calls[0][0];
        const calledParams = querySpy.mock.calls[0][1];

        expect(calledQuery).toContainSQLPatternDynamic(
          "INSERT INTO Player",
          {
            operation: "insertSingle query",
            field: "INSERT statement",
            suggestions: [
              "Make sure to use 'INSERT INTO Player' to add records to the Player table",
              "Check if your insertSingle function starts with the correct INSERT statement",
              "Verify the table name is 'Player' (case-sensitive)"
            ]
          }
        );

        expect(calledQuery).toContainSQLPatternDynamic(
          "(name, level)",
          {
            operation: "insertSingle query",
            field: "column specification",
            suggestions: [
              "Use '(name, level)' - column names should be singular, not plural",
              "Common mistake: using 'names' instead of 'name'",
              "Check your database schema - the columns are 'name' and 'level'"
            ]
          }
        );

        expect(calledQuery).toContainSQLPatternDynamic(
          "VALUES (?, ?)",
          {
            operation: "insertSingle query",
            field: "VALUES clause",
            suggestions: [
              "Include 'VALUES (?, ?)' with parameter placeholders for name and level",
              "Make sure you have the correct number of placeholders (2 for name and level)",
              "Check if your insertSingle function includes the correct VALUES clause"
            ]
          }
        );

        expect(calledParams).toEqualWithContext(
          expect.arrayContaining(["Jessie", 1]),
          "Expected insertSingle to pass player name and level as parameters. Check if your insertSingle function correctly extracts and passes the name and level from the input data."
        );
      }
    } catch (error) {
      throw new Error(`❌ Test execution failed: ${error.message}

🔧 Check:
   - playerModel.js insertSingle function exists and is properly defined
   - Database connection is working
   - No syntax errors in your SQL query`);
    } finally {
      // Always restore the spy to prevent test pollution
      if (querySpy) {
        querySpy.mockRestore();
      }
    }
  });

  test("updateById should call pool.query", () => {
    const mockData = { 
      name: "Super Brock", 
      level: 100, 
      id: 2 
    };
    const mockCallback = () => {};
    let querySpy;

    try {
      querySpy = jest.spyOn(pool, "query");
      model.updateById(mockData, mockCallback);

      // Always check if the spy was called, regardless of success/failure
      expect(querySpy).toHaveBeenCalled();
      
      // Get the query that was called - this should always exist if the function ran
      const calledQuery = querySpy.mock.calls[0][0];
      const calledParams = querySpy.mock.calls[0][1];

      expect(calledQuery).toContainSQLPatternDynamic(
        "UPDATE Player",
        {
          operation: "updateById query",
          field: "UPDATE statement",
          suggestions: [
            "Make sure to use 'UPDATE Player' to modify records in the Player table",
            "Check if your updateById function starts with the correct UPDATE statement",
            "Verify the table name is 'Player' (case-sensitive)"
          ]
        }
      );

      expect(calledQuery).toContainSQLPatternDynamic(
        "SET",
        {
          operation: "updateById query",
          field: "SET clause",
          suggestions: [
            "Include 'SET' clause to specify which fields to update",
            "Check if your updateById function includes the SET clause for updating fields",
            "Make sure the SET clause comes after the UPDATE statement"
          ]
        }
      );

      expect(calledQuery).toContainSQLPatternDynamic(
        "name = ?",
        {
          operation: "updateById query",
          field: "name",
          suggestions: [
            "Include 'name = ?' to update the player's name field (not 'names = ?')",
            "Make sure to use a parameter placeholder (?) for the name value",
            "Common mistake: using 'names = ?' instead of 'name = ?' - column names should be singular"
          ]
        }
      );

      expect(calledQuery).toContainSQLPatternDynamic(
        "level = ?",
        {
          operation: "updateById query",
          field: "level",
          suggestions: [
            "Check if 'level' is the correct column name (not 'levels')",
            "Verify your database schema - the column should be 'level'",
            "Common mistake: using 'levels = ?' instead of 'level = ?' - column names should be singular"
          ]
        }
      );

      expect(calledQuery).toContainSQLPatternDynamic(
        "WHERE id = ?",
        {
          operation: "updateById query",
          field: "WHERE clause",
          suggestions: [
            "Include 'WHERE id = ?' to identify which player to update",
            "Make sure to use a parameter placeholder (?) for the ID value",
            "Check if your updateById function includes the correct WHERE clause"
          ]
        }
      );

      expect(calledParams).toEqualWithContext(
        expect.arrayContaining(["Super Brock", 100, 2]),
        "Expected updateById to pass name, level, and id as parameters in the correct order. Check if your updateById function correctly extracts and passes all required parameters."
      );

    } catch (error) {
      // Fixed: Throw error instead of using fail() which is not available in Jest
      throw new Error(`❌ Test execution failed: ${error.message}

🔧 Check:
   - playerModel.js updateById function exists and is properly defined
   - Database connection is working
   - No syntax errors in your SQL query`);
    } finally {
      // Always restore the spy to prevent test pollution
      if (querySpy) {
        querySpy.mockRestore();
      }
    }
  });

  test("deleteById should call pool.query", () => {
    const mockData = { id: 1 };
    const mockCallback = () => {};
    let querySpy;

    try {
      querySpy = jest.spyOn(pool, "query");
      model.deleteById(mockData, mockCallback);

      // First check that pool.query was actually called
      expect(querySpy).toHaveBeenCalled();

      if (querySpy.mock.calls.length > 0) {
        const calledQuery = querySpy.mock.calls[0][0];
        const calledParams = querySpy.mock.calls[0][1];

        expect(calledQuery).toContainSQLPatternDynamic(
          "DELETE FROM Player",
          {
            operation: "deleteById query",
            field: "DELETE statement",
            suggestions: [
              "Make sure to use 'DELETE FROM Player' to remove records from the Player table",
              "Check if your deleteById function starts with the correct DELETE statement",
              "Verify the table name is 'Player' (case-sensitive)"
            ]
          }
        );

        expect(calledQuery).toContainSQLPatternDynamic(
          "WHERE id = ?",
          {
            operation: "deleteById query",
            field: "WHERE clause",
            suggestions: [
              "Include 'WHERE id = ?' to identify which player to delete",
              "Make sure to use a parameter placeholder (?) for the ID value",
              "Check if your deleteById function includes the correct WHERE clause to identify which player to delete"
            ]
          }
        );

        expect(calledParams).toEqualWithContext(
          expect.arrayContaining([1]),
          "Expected deleteById to pass the player ID as a parameter. Check if your deleteById function correctly extracts and passes the ID from the input data."
        );
      }
    } catch (error) {
      throw new Error(`❌ Test execution failed: ${error.message}

🔧 Check:
   - playerModel.js deleteById function exists and is properly defined
   - Database connection is working
   - No syntax errors in your SQL query`);
    } finally {
      // Always restore the spy to prevent test pollution
      if (querySpy) {
        querySpy.mockRestore();
      }
    }
  });
});
