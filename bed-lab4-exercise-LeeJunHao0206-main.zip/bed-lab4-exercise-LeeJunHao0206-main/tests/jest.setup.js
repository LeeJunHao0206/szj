/**
 * Jest Setup File - Custom Matchers with Context Support
 * This file extends Jest with custom matchers that provide better error messages for students
 */

// ANSI color codes for terminal output
const colors = {
  red: '\x1b[31m',
  green: '\x1b[32m',
  reset: '\x1b[0m',
  bold: '\x1b[1m'
};

// Extend Jest matchers to support withContext for better error messages
expect.extend({
  toBeWithContext(received, expected, context) {
    const pass = received === expected;
    
    if (pass) {
      return {
        message: () => `Expected ${received} not to be ${expected}`,
        pass: true,
      };
    } else {
      return {
        message: () => `❌ ${context}\n\n${colors.bold}Expected:${colors.reset} ${colors.green}${expected}${colors.reset}\n${colors.bold}Received:${colors.reset} ${colors.red}${received}${colors.reset}`,
        pass: false,
      };
    }
  },

  toEqualWithContext(received, expected, context) {
    const pass = this.equals(received, expected);
    
    if (pass) {
      return {
        message: () => `Expected ${JSON.stringify(received)} not to equal ${JSON.stringify(expected)}`,
        pass: true,
      };
    } else {
      return {
        message: () => `❌ ${context}\n\n${colors.bold}Expected:${colors.reset} ${colors.green}${JSON.stringify(expected)}${colors.reset}\n${colors.bold}Received:${colors.reset} ${colors.red}${JSON.stringify(received)}${colors.reset}`,
        pass: false,
      };
    }
  },

  toHavePropertyWithContext(received, property, context) {
    // Helper function to check nested properties using dot notation
    const hasNestedProperty = (obj, path) => {
      if (obj == null) return false;
      
      const keys = path.split('.');
      let current = obj;
      
      for (const key of keys) {
        if (current == null || typeof current !== 'object' || !(key in current)) {
          return false;
        }
        current = current[key];
      }
      
      return true;
    };
    
    const pass = hasNestedProperty(received, property);
    
    if (pass) {
      return {
        message: () => `Expected object not to have property ${property}`,
        pass: true,
      };
    } else {
      return {
        message: () => `❌ ${context}\n\n${colors.bold}Expected object to have property:${colors.reset} ${colors.green}${property}${colors.reset}\n${colors.bold}Received object:${colors.reset} ${colors.red}${JSON.stringify(received)}${colors.reset}`,
        pass: false,
      };
    }
  },

  toContainSQLPatternDynamic(sqlQuery, expectedPattern, context = {}) {
    const pass = sqlQuery.includes(expectedPattern);
    
    if (pass) {
      return {
        message: () => `Expected SQL query not to contain pattern: ${expectedPattern}`,
        pass: true,
      };
    } else {
      // Dynamic error message generation
      const { operation = "SQL operation", field = expectedPattern.replace(" = ?", ""), suggestions = [] } = context;
      
      // Try to find what the user actually used instead
      const queryLines = sqlQuery.split('\n').map(line => line.trim()).filter(line => line);
      const relevantLine = queryLines.find(line => line.includes('=') && line.includes('?')) || sqlQuery;
      
      // Generate suggestions automatically
      const autoSuggestions = suggestions.length > 0 ? suggestions : [
        `Check if '${field}' is the correct column name in your database schema`,
        `Verify the spelling of '${field}' - common mistakes include pluralization or typos`,
        `Make sure your SQL statement uses the exact column names from your table`
      ];
      
      return {
        message: () => `❌ SQL Query Error: Your ${operation} should use '${expectedPattern}' but it was not found.

🔍 Your SQL Query:
${sqlQuery}

❌ Problem: The query should contain '${expectedPattern}'
${relevantLine !== sqlQuery ? `📍 Check this line: ${relevantLine}` : ''}

💡 Suggestions:
${autoSuggestions.map(suggestion => `   • ${suggestion}`).join('\n')}`,
        pass: false,
      };
    }
  }
});