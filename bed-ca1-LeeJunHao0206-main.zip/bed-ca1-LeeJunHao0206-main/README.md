Project Overview

This system implements a RESTful backend API using Node.js, Express, and MySQL.

The system supports user management, wellness challenges, challenge completion records,
and a gamified pet system where users can own pets, earn points from completing wellness
challenges, redeem pet items using earned points, and interact with their pets.


Dependencies

The project uses the following technologies and libraries:
- Node.js
- Express.js
- MySQL
- mysql2
- dotenv
- Postman (Used for API testing)

Callbacks and middleware are used throughout the project.


Project Structure

routes/
- API route definitions

controllers/
- Request handling, validation, and middleware logic

models/
- Database queries and data access logic

configs/
- Database configuration files


Setup Instructions

1. Install all required dependencies
npm install

2. Create a .env file in the project root directory and configure the database connection

Example:
DB_HOST=localhost
DB_USER=your_database_user
DB_PASSWORD=your_database_password
DB_NAME=your_database_name

3. Run the database initialisation script to create the required tables.

4. Start the server
node index.js

The server will start running on the configured port (default: localhost:3000).


Core Features

User Management
- Create users
- Retrieve all users
- Retrieve user by ID
- Update user details
- Validation for missing data and duplicate usernames

Wellness Challenges
- Create wellness challenges
- Retrieve all challenges
- Retrieve challenge attempts by challenge ID
- Update challenges with ownership validation
- Delete challenges

Challenge Completion and Points System
- Users can complete wellness challenges
- Completion records are stored in the database
- Users earn points when completing challenges
- Points are accumulated and used in the gamification system


Gamification Features

Pet System
- Users can create pets
- Pets are associated with users
- Users can retrieve all pets belonging to them

Item Redemption System
- Users can redeem predefined pet items using points earned from completing wellness challenges
- Pet items are predefined in the database
- Each item has a point cost
- Users must have sufficient points to redeem an item
- Successful redemption deducts user points and records the redemption


Database Design (ERD Explanation)

The ERD represents the logical data model of the system.

The database includes the original wellness challenge tables as well as additional
gamification-related tables such as pets, pet items, and item redemption.

Relationships between tables are enforced at the application layer using middleware
validation rather than database-level foreign key constraints. This approach aligns
with the assignment scope and keeps the database design simple and consistent with the
backend implementation.

Examples of logical relationships:
- UserCompletion.user_id references User.user_id
- UserCompletion.challenge_id references WellnessChallenge.challenge_id
- Pet.user_id references User.user_id
- ItemRedemption.user_id references User.user_id
- ItemRedemption.item_id references PetItems.item_id

The ERD diagram is included in the BED CA1 Report.


Error Handling

The API uses consistent HTTP status codes:
- 400 Bad Request – Missing or invalid request data
- 403 Forbidden – Insufficient permissions or points
- 404 Not Found – Requested resource does not exist
- 409 Conflict – Duplicate resource conflicts
- 500 Internal Server Error – Database or server errors


Testing

All endpoints have been tested using Postman.

Screenshots demonstrating both successful responses and error handling cases for each
endpoint are included in the BED CA1 Report, in accordance with the assignment
requirements.


Notes for Reviewers

- Validation and relationships are handled at the application layer.
- All required endpoints specified in the CA1 brief are implemented and tested.


Conclusion

This project demonstrates a complete backend API with proper validation, middleware usage,
error handling, and a gamified points-based system.
