const challengesModel = require("../models/challengesModel.js");

// To create a new challenge
module.exports.createNewChallenges = (req, res, next) =>{
    if(!req.body.description || !req.body.user_id || ! req.body.points){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        description: req.body.description,
        user_id: req.body.user_id,
        points: req.body.points
    }

    const callback = (error, results, fields) => {
        if(error){
            console.log("Error createNewChallenges: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        else{
        return res.status(201).json({challenge_id: results.insertId, description: data.description, creator_id: data.user_id, points: data.points})
        }
    }

    challengesModel.createNewChallenges(data, callback)
}

// To retreive all challenges
module.exports.getAllChallenges = (req, res, next) =>
{
    const callback = (error, results, fields) => {
        if(error){
            console.groupCollapsed("Error getAllChallenges: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        return res.status(200).json(results)
    }
    challengesModel.getAllChallenges(callback)
}

// To delete completion record from usercompletion table
module.exports.deleteCompletionRecordbyId = (req, res, next) =>
{
    if(!req.params.challenge_id){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        id: req.params.challenge_id
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error deleteCompletionRecordbyId: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        else{
            res.locals.id = data.id
            next();
        }
    }
    challengesModel.deleteCompletionRecordbyId(data, callback)
}

// To delete challenge by challenge_id
module.exports.deleteChallengebyId = (req, res, next) =>
{

    const data = {
        id: res.locals.id
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error deleteChallengebyId: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        if(results.affectedRows === 0){
            return res.status(404).json({message: "Challenge does not exist"})
        }
        return res.status(204).send()
    }
    challengesModel.deleteChallengebyId(data,callback)
}

// To check if the challenge exist
module.exports.checkforChallengeValidation = (req, res, next) =>
{
    if(!req.params.challenge_id || !req.body.user_id || !req.body.description || ! req.body.points){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        id: req.params.challenge_id,
        userId: req.body.user_id,
        description: req.body.description,
        points: req.body.points
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error checkforChallengeValidation: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        if(results.length === 0){
            return res.status(404).json({message: "Challenge does not exist "})
        }
        if(results[0].creator_id !== data.userId){
            return res.status(403).json({message: "Not correct owner"})
        }
        else{
            res.locals.id = data.id
            res.locals.userId = data.userId
            res.locals.description = data.description
            res.locals.points = data.points
            next();
        }
    }
    challengesModel.checkforChallengeValidation(data, callback)
}

// Update the challenge that is checked by by middleware above
module.exports.updateChallengeDetails = (req, res, next) =>
{
    const data = {
        id: res.locals.id,
        userId: res.locals.userId,
        description: res.locals.description,
        points: res.locals.points
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error updateChallengeDetails: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        return res.status(200).json({challenge_id: data.id, description: data.description, creator_id: data.userId, points: data.points})
    }

    challengesModel.updateChallengeDetails(data, callback)
}