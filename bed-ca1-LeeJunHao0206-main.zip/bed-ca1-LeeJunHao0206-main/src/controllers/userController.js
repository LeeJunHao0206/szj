const userModel = require("../models/userModel.js");

//To check if username in used by other user
module.exports.checkIfUserExist = (req, res,next) =>
{
    if(!req.body.username){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        username: req.body.username
    }

    const callback = (error, results, fields) =>{
        if(error){
            console.error("Error checkIfUserExist:", error)
            return res.status(500).json(error)
        }

        if(results.length > 0){
            return res.status(409).json({message: "Username has been used"})
        }
        else{
            res.locals.username = data.username
            next();
        }
    }

    userModel.checkIfUserExist(data, callback)
}

//To create a new user
module.exports.createNewUser = (req, res, next) => {
    if(!res.locals.username){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        username: res.locals.username
    }

    const callback = (error, results, field) =>{
        if(error){
            console.error("Error createNewUser: ", error)
            return res.status(500).json(error)
        }

        else{
            res.locals.userId = results.insertId
            next()
        }
    }
    userModel.createNewUser(data, callback)
}

// To retrieve the user data created 
module.exports.getUserbyUserId = (req, res, next) =>
{
    if(!res.locals.userId){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        userId: res.locals.userId
    }

    const callback = (error, results, next) =>
    {
        if(error){
            console.error("Error getUserbyUserId: ", error)
            return res.status(500).json({message: "Internal server error"})
        }

        else{
            return res.status(201).json(results[0])
        }
    }
    userModel.getUserbyUserId(data, callback)
}

// To retrieve all the users data
module.exports.readAllUsers = (req, res, next) =>
{
    const callback = (error, results, fields) =>{
        if(error){
            console.error("Error readAllUsers: ", error)
            return res.status(500).json(error)
        }
        return res.status(200).json(results)
    }
    userModel.readAllUsers(callback)
}

// To retrieve user data by user_id
module.exports.readUserbyId = (req, res, next) =>
{
    if(!req.params.userId){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        id: req.params.userId
    }

    const callback = (error, results, fields) => {
        if(error){
            console.error("Error readUserbyId: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        if(results.length === 0){
            return res.status(404).json({message: "User does not exist"})
        }
        else{
            return res.status(200).json(results[0])
        }
    }
    userModel.readUserbyId(data, callback)
}

// To check if the user_id exist
module.exports.checkUserbyId = (req, res, next) =>
{
    if(!req.params.userId){
        return res.status(400).json({message: "Missing required data"})
    }
    const data = {
        id: req.params.userId
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.error("Error checkUserbyId: ", error)
            return res.status(500).json(error)
        }
        if(results.length === 0){
            return res.status(404).json({message: "User does not exist "})
        }
        else{
            res.locals.id = data.id
            next();
        }
    }
    userModel.checkUserbyId(data, callback)
}

// To check if the username in body is in used by another user
module.exports.checkUserbyUsername = (req, res, next) => {
    if(!res.locals.id || ! req.body.username){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        id: res.locals.id,
        username: req.body.username
    }

    const callback = (error, results, fields) =>{
        if(error){
            console.error("Error checkUserbyUsername: ", error)
            return res.status(500).json(error)
        }
        if(results.length > 0){
            return res.status(409).json({message: "Username is associated with another user"})
        }
        else{
            res.locals.id = data.id
            res.locals.username = data.username
            next()
        }
    }
    userModel.checkUserbyUsername(data, callback)
}

// To update user with data provided
module.exports.updateUser = (req, res, next) =>
{
    if(!res.locals.username || !res.locals.id || req.body.points === null){
        return res.status(400).json({message: "Missing required data"})
    }
    const data = {
        username: res.locals.username,
        points: req.body.points,
        userId: res.locals.id   
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.error("Error updateUser: ", error)
            return res.status(500).json(error)
        }
        if(results.affectedRows === 0){
            return res.status(404).json({message: "User does not exist"})
        }
        else{
            res.locals.userId = data.userId
            next();
        }
    }
    userModel.updateUser(data, callback)
}