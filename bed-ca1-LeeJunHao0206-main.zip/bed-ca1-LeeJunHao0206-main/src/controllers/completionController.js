const completionModel = require("../models/completionModel.js");

// To check if user_id and challenge_id are both valid data
module.exports.checkValidation = (req, res, next) =>
{
    if(!req.params.challenge_id || !req.body.user_id || !req.body.details){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        challengeId: req.params.challenge_id,
        userId: req.body.user_id,
        details: req.body.details
    }

    const callback = (error, results, details) => {
        if(error){
            console.log("Error checkValidation: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        if(results.length === 0){
            return res.status(404).json({message: "Challenge or user does not exist"})
        }
        else{
            res.locals.challengeId = data.challengeId
            res.locals.userId = data.userId
            res.locals.details = data.details
            next()
        }
    }
    completionModel.checkValidation(data, callback)
}

// To create a completion record for user
module.exports.createCompletionRecord = (req, res, next) =>
{
    const data = {
        challengeId: res.locals.challengeId,
        userId: res.locals.userId,
        details: res.locals.details
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error checkValidation: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        else{
            res.locals.completionId = results.insertId
            next();
        }
    }
    completionModel.createCompletionRecord(data, callback)
}

// To check if user exist
module.exports.checkUserExist = (req, res, next) =>
{
    if(!req.body.user_id){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = {
        userId: req.body.user_id
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error checkUserExist: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        if(results.length === 0){
            return res.status(404).json({message: "User does not exist"})
        }
        else{
            res.locals.userId = data.userId
            next();
        }
    }
    completionModel.checkUserExist(data, callback)
}

// To retrieve points from challenge by challenge_id
module.exports.getPoints = (req, res, next) =>
{
    const data = {
        challengeId: req.params.challenge_id
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error getPoints: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        if(results.length === 0){
            return res.status(404).json({message: "Challenge does not exist"})
        }
        else{
            res.locals.points = results[0].points
            next();
        }
    }
    completionModel.getPoints(data, callback)
}

// To add on points retrieved to the user who complete the challenge
module.exports.incrementUserPoints = (req, res, next) =>
{
    const data = {
        userId: res.locals.userId,
        points: res.locals.points
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error incrementUserPoints: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        else{
            next();
        }
    }
    completionModel.incrementUserPoints(data, callback)
}

// To show the points of the user after increment
module.exports.showPoints = (req, res, next) =>
{
    const data = {
        userId: res.locals.userId
    }

    const callback = (error, results, field) =>
    {
        if(error){
            console.log("Error showPoints: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        return res.status(201).json({complete_id: res.locals.completionId, challenge_id: res.locals.challengeId, user_id: res.locals.userId, details: res.locals.details})
    }
    completionModel.showPoints(data, callback)
}

// To retrieve user_id and details by challenge_id
module.exports.getUsersbyChallengeId = (req, res, next) =>
{
    const data = {
        id: req.params.challenge_id
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error getUsersbyChallengeId: ", error)
            return res.status(500).json({message: "Internal server error"})
        }
        if(results.length === 0){
            return res.status(404).json({message: "This challenge does not have any user attempt"})
        }
        return res.status(200).json(results)
    }
    completionModel.getUsersbyChallengeId(data, callback)
}