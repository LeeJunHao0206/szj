const itemsModel = require("../models/itemsModel.js");

// To retrieve all items from database
module.exports.getAllItems = (req, res, next) =>
{
    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error getAllItems: ", error)
            return res.status(500).json({message: "Internal system error"})
        }

        return res.status(200).json(results)
    }
    itemsModel.getAllItems(callback)
}

// To check if the user exist in database by using provided user_id
module.exports.checkIfUserExist = (req, res, next) =>
{
    if(!req.body.user_id){
        return res.status(400).json({message: "Missing required data"})
    }

    const data = 
    {
        userId:req.body.user_id
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error checkIfUserExist: ", error)
            return res.status(500).json({message: "Internal system error"})
        }
        if(results.length === 0){
            return res.status(404).json({message: "User does not exist"})
        }
        else{
            res.locals.userId = data.userId
            next();
        }
    }
    itemsModel.checkIfUserExist(data, callback)
}

// To check if the item exist in database by using provided item_id
module.exports.checkIfItemExist = (req, res, next) =>
{
    if (!req.body.item_id){
        return res.status(400).json({message: "Missing requried data"})
    }

    const data = {
        itemId: req.body.item_id
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error checkIfItemExist: ", error)
            return res.status(500).json({message: "Internal system error"})
        }

        if(results.length === 0){
            return res.status(404).json({message: "Item does not exist"})
        }

        else{
            res.locals.itemId = data.itemId
            next();
        }
    }
    itemsModel.checkIfItemExist(data, callback)
}

// To retrieve points from user by user_id
module.exports.getUserPoints = (req, res, next) =>
{
    const data = {
        userId: res.locals.userId
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error getUserPoints: ", error)
            return res.status(500).json({message: "Internal system error"})
        }

        if(results.length === 0){
            return res.status(404).json({message: "User does not exist"})
        }
        else{
            res.locals.userPoints = results[0].points
            next();
        }
    }
    itemsModel.getUserPoints(data, callback)
}

// To retrieve cost from item by item_id
module.exports.getItemCost = (req, res, next) =>
{
    const data = {
        itemId: res.locals.itemId
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error getItemCost: ", error)
            return res.status(500).json({message: "Internal system error"})
        }
        if(results.length === 0){
            return res.status(404).json({message: "Item does not exist"})
        }
        if(res.locals.userPoints < results[0].cost){
            return res.status(403).json({message: "Insufficient points"})
        }
        else{
            res.locals.itemCost = results[0].cost
            next();
        }
    }
    itemsModel.getItemCost(data, callback)
}

// To check if user have sufficient points to afford item and perform points deduction
module.exports.pointsDeduction = (req, res, next) =>
{
    const data = {
        itemCost: res.locals.itemCost,
        userId: res.locals.userId
    }
    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error pointsValidation: ", error)
            return res.status(500). json({message: "Internal system error"})
        }
        else{
            next();
        }
    }
    itemsModel.pointsDeduction(data, callback)
}

// To add item under the user_id provided in redemption table and return appropriate message
module.exports.itemRedemption = (req, res, next) =>
{
    const data = {
        userId: res.locals.userId,
        itemId: res.locals.itemId
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error itemRedemption: ", error)
            return res.status(500).json({message: "Internal system error"})
        }
        return res.status(201).json({message: "Item redeemed successfully"})
    }
    itemsModel.itemRedemption(data, callback) 
}