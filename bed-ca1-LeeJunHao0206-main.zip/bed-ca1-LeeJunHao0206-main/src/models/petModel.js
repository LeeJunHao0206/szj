const pool = require("../services/db");

// To check if the user exist by user_id
module.exports.checkUser = (data, callback) =>
{
    const SQL = 
    `
    SELECT * FROM user
    WHERE user_id = ?
    ;`;
    const VALUES = [data.id]
    pool.query(SQL, VALUES, callback)
}

// To create a new pet and ensure it is associated with user_id provided
module.exports.createPets = (data, callback) =>
{
    const SQL =
    `
    INSERT INTO pet (user_id, pet_name, pet_type)
    VALUES (?, ?, ?)
    ;`;

    const VALUES = [data.userId, data.petName, data.petType]
    pool.query(SQL, VALUES, callback)
}

// To check if the user exist by user_id
module.exports.checkIfUserExistbyId = (data, callback) =>
{
    const SQL =
    `
    SELECT user_id FROM user
    WHERE user_id = ?
    ;`;
    const VALUES = [data.id]
    pool.query(SQL, VALUES, callback)
}

// To retrieve all pets that were associated with the user_id provided
module.exports.getPetsbyUserId = (data, callback) =>
{
    const SQL = 
    `
    SELECT pet_name, pet_type FROM pet
    WHERE user_id = ?
    ;`;

    const VALUES = [data.id]
    pool.query(SQL, VALUES, callback)
}