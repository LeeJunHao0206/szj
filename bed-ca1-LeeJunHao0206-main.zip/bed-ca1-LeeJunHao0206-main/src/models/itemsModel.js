const pool = require("../services/db");

// To retrieve all of the items 
module.exports.getAllItems = (callback) =>
{
    const SQL = 
    `
    SELECT * FROM PetItems
    ;`;
    pool.query(SQL, callback)
}

// To check if the user exist with provided user_id
module.exports.checkIfUserExist = (data, callback) =>
{
    const SQL =
    `
    SELECT * FROM user
    WHERE user_id = ?
    ;`;
    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

// To check if the item exist with provided item_id
module.exports.checkIfItemExist = (data, callback) =>
{
    const SQL =
    `
    SELECT item_name FROM PetItems
    WHERE item_id = ?
    ;`;

    const VALUES = [data.itemId]

    pool.query(SQL, VALUES, callback)
}

// To retrieve points from user with provided user_id
module.exports.getUserPoints = (data, callback) =>
{
    const SQL =
    `
    SELECT points FROM user
    WHERE user_id = ?
    ;`;

    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

// To retrieve cost from PetItem with provided item_id
module.exports.getItemCost = (data, callback) =>
{
    const SQL =
    `
    SELECT cost FROM PetItems
    WHERE item_id = ?
    ;`;
    const VALUES = [data.itemId]
    pool.query(SQL, VALUES, callback)
}

// To deduct points from user when they have successfully redeem item
module.exports.pointsDeduction = (data, callback) =>
{
    const SQL =
    `
    UPDATE user
    SET points = points - ?
    WHERE user_id = ?
    ;`;
    const VALUES = [data.itemCost, data.userId]
    pool.query(SQL, VALUES, callback)
}

// To add the item which the user wants to redeem
module.exports.itemRedemption = (data, callback) =>
{
    const SQL =
    `
    INSERT INTO ItemRedemption (user_id, item_id)
    VALUES(?, ?)
    ;`;

    const VALUES = [data.userId, data.itemId]
    pool.query(SQL, VALUES, callback)
}

