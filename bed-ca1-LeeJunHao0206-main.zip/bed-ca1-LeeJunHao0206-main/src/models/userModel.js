const pool = require("../services/db");

// To check if the user exist by user_id
module.exports.checkIfUserExist = (data, callback) =>
{
    const SQL = `
    SELECT * 
    FROM user
    WHERE username = ?;
    `;

    const VALUES = [data.username]
    pool.query(SQL, VALUES, callback)
};

// To  create a new user with data provided
module.exports.createNewUser = (data, callback) =>
{
    const SQL = `
        INSERT INTO user (username)
        VALUES (?);
    `;
    const VALUES = [data.username]
    pool.query(SQL, VALUES, callback)
}

// To retrieve all the data of the created user by user_id
module.exports.getUserbyUserId = (data, callback) =>
{
    const SQL = `
    SELECT * 
    FROM user
    WHERE user_id = ?;
    `;
    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

// To retrieve all users
module.exports.readAllUsers = (callback) =>
{
    const SQL =`
    SELECT * FROM user
    ;`;

    pool.query(SQL, callback)
}

// To retrieve the details of the user by user_id
module.exports.readUserbyId = (data, callback) =>
{
    const SQL = `
    SELECT * FROM user
    WHERE user_id = ?
    ;`;
    const VALUES = [data.id]
    pool.query(SQL, VALUES, callback)
}

// To check if the user exist by user_id
module.exports.checkUserbyId = (data, callback) =>
{
    const SQL = `
    SELECT * FROM user
    WHERE user_id = ?
    ;`;

    const VALUES = [data.id]
    pool.query(SQL, VALUES, callback)
}

// To check if the username is in used by another user
module.exports.checkUserbyUsername = (data, callback) =>
{
    const SQL = `
    SELECT * FROM user
    WHERE username = ?
    ;`;
    const VALUES = [data.username]
    pool.query(SQL, VALUES, callback)
}

// To update the details of the user by user_id
module.exports.updateUser = (data, callback) =>
{
    const SQL =`
    UPDATE user
    SET username = ?, points = ?
    WHERE user_id = ?
    ;`;
    const VALUES = [data.username, data.points, data.userId]
    pool.query(SQL, VALUES, callback)
}