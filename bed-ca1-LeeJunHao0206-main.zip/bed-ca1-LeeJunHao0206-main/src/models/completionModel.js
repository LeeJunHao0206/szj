const pool = require("../services/db")

module.exports.checkValidation = (data, callback) =>
{
    const SQL =
    `
    SELECT user.username, wellnesschallenge.description
    FROM user, wellnesschallenge
    WHERE user.user_id = ? AND wellnesschallenge.challenge_id = ?
    ;`;
    const VALUES = [data.userId, data.challengeId]
    pool.query(SQL, VALUES, callback)
}

module.exports.createCompletionRecord = (data, callback) =>
{
    const SQL =
    `
    INSERT INTO usercompletion (challenge_id, user_id, details)
    VALUES (?, ?, ?)
    ;`;
    const VALUES = [data.challengeId, data.userId, data.details]
    pool.query(SQL, VALUES, callback)
}

// To check if the user exist by user_id
module.exports.checkUserExist = (data, callback) =>
{
    const SQL=
    `
    SELECT user_id FROM user
    WHERE user_id = ?
    ;`;
    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

// To retrieve the points from challenge by challenge_id
module.exports.getPoints = (data, callback) =>
{
    const SQL =`
    SELECT points FROM wellnesschallenge
    WHERE challenge_id = ?
    ;`;
    const VALUES = [data.challengeId]
    pool.query(SQL, VALUES, callback)
}

// To add the points retrieved to the user who completed the challenge
module.exports.incrementUserPoints = (data, callback) =>
{
    const SQL =
    `
    UPDATE user
    SET points = user.points + ?
    WHERE user_id = ?
    ;`;
    const VALUES = [data.points, data.userId]
    pool.query(SQL, VALUES, callback)
}

//To retrieve the points of the user after increment
module.exports.showPoints = (data, callback) =>
{
    const SQL =
    `
    SELECT points FROM user
    WHERE user_id = ?
    ;`;
    const VALUES = [data.userId]
    pool.query(SQL, VALUES, callback)
}

// To retrieve user_id and details of the challenge by challenge_id 
module.exports.getUsersbyChallengeId = (data, callback) =>
{
    const SQL =
    `
    SELECT user_id, details FROM usercompletion
    WHERE challenge_id = ?
    ;`;
    const VALUES = [data.id]
    pool.query(SQL, VALUES, callback)
}