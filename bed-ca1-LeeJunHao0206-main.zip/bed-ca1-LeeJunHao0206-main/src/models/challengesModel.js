const pool = require("../services/db");

// To create a new challenge
module.exports.createNewChallenges = (data, callback) =>
{
    const SQL =  `
    INSERT INTO wellnesschallenge (creator_id, description, points)
    VALUES (?, ?, ?)
    ;`;

    const VALUES = [data.user_id, data.description, data.points]
    pool.query(SQL, VALUES, callback)
}

// To retrieve all the challenges
module.exports.getAllChallenges = (callback) =>
{
    const SQL =
    `
    SELECT * from wellnesschallenge
    ;`;

    pool.query(SQL, callback)
}

// To delete completion record in usercompletion table
module.exports.deleteCompletionRecordbyId = (data, callback) =>
{
    const SQL=
    `
    DELETE FROM usercompletion
    WHERE challenge_id = ?
    ;`;
    const VALUES = [data.id]
    pool.query(SQL, VALUES, callback)
}

// To delete challenge by challenge_id
module.exports.deleteChallengebyId = (data, callback) =>
{
    const SQL =
    `
    DELETE from wellnesschallenge
    WHERE challenge_id = ?
    ;`;

    const VALUES = [data.id]
    pool.query(SQL, VALUES, callback)
}

// To check if the challenge exist by challenge_id
module.exports.checkforChallengeValidation = (data, callback) =>
{
    const SQL =
    `
    SELECT * FROM wellnesschallenge
    WHERE challenge_id = ?
    ;`;

    const VALUES = [data.id]
    pool.query(SQL, VALUES, callback)
}

// To update details of the challenge
module.exports.updateChallengeDetails = (data, callback) =>
{
    const SQL =
    `
    UPDATE wellnesschallenge
    SET creator_id = ?, description = ?, points = ?
    WHERE challenge_id = ?
    ;`;

    const VALUES = [data.userId, data.description, data.points, data.id]
    pool.query(SQL, VALUES, callback)
}