const express = require("express")
const router = express.Router()

const userRoutes = require("./userRoutes")
const challengesRoutes = require("./challengesRoutes")
const petRoutes = require("./petRoutes")
const itemsRoutes = require("./itemsRoutes")


router.use("/users", userRoutes);
router.use("/challenges", challengesRoutes)
router.use("/pet", petRoutes)
router.use("/items", itemsRoutes)

module.exports = router