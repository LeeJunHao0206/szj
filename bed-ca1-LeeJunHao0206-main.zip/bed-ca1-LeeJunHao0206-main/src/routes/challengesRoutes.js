const express = require("express");
const router = express.Router()

const controller = require("../controllers/challengesController");
const completionController = require("../controllers/completionController");

router.post('/', controller.createNewChallenges)
router.post("/:challenge_id", completionController.checkValidation, completionController.createCompletionRecord, completionController.getPoints, completionController.incrementUserPoints, completionController.showPoints)

router.get('/', controller.getAllChallenges)
router.get("/:challenge_id", completionController.getUsersbyChallengeId)

router.delete('/:challenge_id', controller.deleteCompletionRecordbyId, controller.deleteChallengebyId)

router.put('/:challenge_id', controller.checkforChallengeValidation, controller.updateChallengeDetails)

module.exports = router;