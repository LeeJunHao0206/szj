const express = require("express");
const router = express.Router()

const controller = require("../controllers/petController");

router.get('/:userId', controller.checkIfUserExistbyId, controller.getPetsbyUserId)

router.post("/", controller.checkUser , controller.createPets)

module.exports = router;