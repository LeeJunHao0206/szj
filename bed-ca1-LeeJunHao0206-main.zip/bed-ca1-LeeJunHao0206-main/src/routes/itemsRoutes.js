const express = require("express");
const router = express.Router()

const controller = require("../controllers/itemsController");

router.get("/", controller.getAllItems)

router.post("/", controller.checkIfUserExist, controller.checkIfItemExist, controller.getUserPoints, controller.getItemCost, controller.pointsDeduction, controller.itemRedemption)

module.exports = router;