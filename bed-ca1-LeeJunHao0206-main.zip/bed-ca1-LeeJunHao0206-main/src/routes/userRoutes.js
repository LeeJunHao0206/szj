const express = require("express");
const router = express.Router()

const controller = require("../controllers/userController");

router.get('/', controller.readAllUsers)
router.get('/:userId', controller.readUserbyId)

router.post('/', controller.checkIfUserExist, controller.createNewUser, controller.getUserbyUserId)

router.put('/:userId', controller.checkUserbyId, controller.checkUserbyUsername, controller.updateUser, controller.readUserbyId)

module.exports = router;