// Name: Lee Jun Hao, Admission number: p2500234, Class: DAAA/FT/1B/06

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require("express");
const router = express.Router()

// ##############################################################
// CREATE ROUTER
// ##############################################################
const usersRoutes = require("./usersRoutes")
const treesRoutes = require('./treesRoutes')

// ##############################################################
// DEFINE ROUTES
// ##############################################################
router.use('/users', usersRoutes )
router.use("/trees", treesRoutes);

// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router