// Name: Lee Jun Hao, Admission number: p2500234, Class: DAAA/FT/1B/06

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require("express");
const router = express.Router()

// ##############################################################
// CREATE ROUTER
// ##############################################################
const controller = require("../controllers/treesController")

// ##############################################################
// DEFINE ROUTES
// ##############################################################
router.get("/:id", controller.selectTreebyId);
router.get("/", controller.readAllTrees);

router.post("/", controller.createTree);
router.delete("/:id", controller.deleteTree);
router.put("/:id", controller.updateTree);

// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router;