// Name: Lee Jun Hao, Admission number: p2500234, Class: DAAA/FT/1B/06

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require("express");
const router = express.Router()

// ##############################################################
// CREATE ROUTER
// ##############################################################
const controller = require("../controllers/usersController")

// ##############################################################
// DEFINE ROUTES
// ##############################################################
router.put("/:userid/trees/:treeid/water", controller.readTreebyUserId, controller.waterTreebyUserId)

router.get("/:id/trees", controller.treesOwnership)
router.get("/:id/trees/average-age", controller.averageAge)

// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router;