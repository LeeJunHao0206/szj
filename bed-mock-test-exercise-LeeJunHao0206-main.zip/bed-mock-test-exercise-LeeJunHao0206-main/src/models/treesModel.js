// Name: Lee Jun Hao, Admission number: p2500234, Class: DAAA/FT/1B/06

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

// ##############################################################
// DEFINE INSERT OPERATION FOR TREE
// ##############################################################
module.exports.createTree = (data, callback) =>
{
    const SQLSTATMENT = `
    INSERT INTO tree (species, age, height, user_id)
    VALUES ( ?, ?, ?, ?);
    `;
const VALUES = [data.species, data.age, data.height, data.user_id];

pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE SELECT ALL OPERATIONS FOR TREE
// ##############################################################
module.exports.readTrees = (callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM tree;
    `;

pool.query(SQLSTATMENT, callback);
}

// ##############################################################
// DEFINE SELECT BY ID OPERATIONS FOR TREE
// ##############################################################
module.exports.selectTreebyId = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM tree
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}


// ##############################################################
// DEFINE UPDATE OPERATIONS FOR TREE
// ##############################################################
module.exports.updateTree = (data, callback) =>{
    const SQLSTATMENT = `
    UPDATE tree 
    SET species = ?, age = ?, height = ?, user_id = ?
    WHERE id = ?;
    `;
const VALUES = [data.species, data.age, data.height, data.user_id, data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE DELETE OPERATIONS FOR TREE
// ##############################################################
module.exports.deleteTree = (data, callback) =>
{
    const SQLSTATMENT = `
    DELETE FROM tree 
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}