// Name: Lee Jun Hao, Admission number: p2500234, Class: DAAA/FT/1B/06

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

// ##############################################################
// DEFINE SELECT TREES BY USER ID
// ##############################################################
module.exports.treeOwnership = (data, callback) =>
{
    const SQLSTATEMENT = `
    SELECT * FROM tree
    WHERE user_id = ?
    `;
const VALUES = [data.userId];

pool.query(SQLSTATEMENT, VALUES, callback);
}

// ##############################################################
// DEFINE WATER TREE BY USER ID
// ##############################################################
module.exports.readTreebyUserId = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT user_id FROM tree
    WHERE id = ?;
    `;
const VALUES = [data.treeId];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.waterTreebyUserId = (data, callback) =>
{
    const SQLSTATMENT = `
    UPDATE tree
    SET watered_on = NOW()
    WHERE id = ?;
    `;
const VALUES = [data.treeId];

pool.query(SQLSTATMENT, VALUES, callback);
}


// ##############################################################
// DEFINE MODEL FOR GET AVERAGE AGE OF TREES OWNED BY USER
// ##############################################################
module.exports.averageAge = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT
    COUNT(*) AS number_of_trees,
    AVG(age) AS average_age
    FROM tree
    WHERE user_id = ?
    `;
const VALUES = [data.userId];

pool.query(SQLSTATMENT, VALUES, callback);
}