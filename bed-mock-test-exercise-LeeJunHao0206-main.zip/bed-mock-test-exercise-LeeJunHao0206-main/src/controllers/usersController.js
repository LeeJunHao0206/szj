// Name: Lee Jun Hao, Admission number: p2500234, Class: DAAA/FT/1B/06

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const usersModel = require("../models/usersModel");

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR READ TREE BY USERID
// ##############################################################
module.exports.readTreebyUserId = (req, res, next) => {
  const data = {
    userId: req.params.userid,
    treeId: req.params.treeid
  };

  if(!data.userId || !data.treeId){
    return res.status(400).json({message: "userId and treeId are required"})
  }

  const callback = (error, results, fields) =>
  {
        if(error){
            console.error("Error readTreebyUserId: ", error)
            return res.status(500).json(error)
        }

        if(results.length == 0){
            return res.status(404).json({message: "Tree not found."})
        }
        const user_Id = results[0].user_id
        if(user_Id != data.userId){
            return res.status(403).json({message: "Tree does not belong to user"})
        }
        else{
            next();
        }
  }

  usersModel.readTreebyUserId(data, callback);
};

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR WATER TREE BY USERID
// ##############################################################
module.exports.waterTreebyUserId = (req, res, next) => {
    const data = {
        userId: req.params.userid,
        treeId: req.params.treeid
    }
    if(!data.userId || !data.treeId){
    return res.status(400).json({message: "userId and treeId are required"})
  }

  const callback = (error, results, fields) =>{
    if(error){
        return res.status(500).json(error)
    }

    else{
        return res.status(204).send()
    }
  }

  usersModel.waterTreebyUserId(data, callback)

}
// ##############################################################
// DEFINE MIDDLEWARE FUNCTION FOR CHECK TREE OWNERSHIP
// ##############################################################
module.exports.treesOwnership = (req, res, next) =>{
    const data = {
        userId: req.params.id
    }

    if(!data.userId){
        return res.status(400).json({messgae: "userId is required"})
    }

    const callback = (error, results, fields) =>{
        if(error){
            return res.status(500).json(error)
        }
        else{
            return res.status(200).json(results)
        }
    }
    usersModel.treeOwnership(data, callback)
}
// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR GET AVERAGE AGE OF
// TREES OWNED BY USER
// ##############################################################
module.exports.averageAge = (req, res, next) =>
{
    const data = {
        userId: req.params.id
    }

    if(!data.userId){
        return res.status(500).json(error)
    }

    const callback = (error, results, fields) =>
    {
        if(error){
            console.error("Error averageAge: ", error);
            return res.status(500).json(error)
        // }else if(results.length == 0){
        //     return res.status(404).json({message: "No trees found."})
        // }
        // else{
        //     return res.status(200).json({averageAge: results.average_age, numberOfTrees: results.numberOfTrees})
        }

        if(results[0].number_of_trees === 0){
            return res.status(404).json({message: "No trees found."})
        }            else return res.status(200).json(results)
        
    }
    usersModel.averageAge(data, callback)
}