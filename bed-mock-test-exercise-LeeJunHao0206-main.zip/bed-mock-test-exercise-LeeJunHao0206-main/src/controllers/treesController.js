// Name: Lee Jun Hao, Admission number: p2500234, Class: DAAA/FT/1B/06

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const treesModel = require("../models/treesModel");

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR CREATE TREE
// ##############################################################

module.exports.createTree = (req, res, next) => {
  const data = {
      species: req.body.species,
      age: req.body.age,
      height: req.body.height,
      user_id: req.body.user_id
    }  
  
  if(!data.species|| !data.age || !data.height || !data.user_id ){
      return res.status(400).json({message: "species, age, height and user_id are required"})
    }

    const callback = (error, results, fields) => {
    if(error){
      console.error("Error createTree:", error)
      return res.status(500).json(error)
    } else {
      return res.status(201).json({message: 'Trees created successfully.', treeId: results.insertId})
    }
  }
  treesModel.createTree(data, callback);
}   

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR READ ALL TREES
// ##############################################################
module.exports.readAllTrees = (req, res, next) => {
    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readTrees:", error);
            res.status(500).json(error);
        } 
        else res.status(200).json(results);
    }

    treesModel.readTrees(callback);
}
// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR READ TREE BY ID
// ##############################################################
module.exports.selectTreebyId = (req, res, next) => {
    const data = {
        id: req.params.id
    }

    if(!data.id){
        res.status(400).json("message: Tree id is required")
    }

    const callback = (error, results, fields) => {
        if(error){
            console.error("Error selectTreebyId: ", error)
        }
        if(results.length === 0){
            res.status(404).json("message: Tree not found")
        }else{
            res.status(200).json(results)
        }

    }
    treesModel.selectTreebyId(data, callback)
}
// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR UPDATE TREE BY ID
// ##############################################################
module.exports.updateTree = (req, res, next) => {
    const data = {
        id: req.params.id,
        species: req.body.species,
        age: req.body.age,
        height: req.body.height,
        user_id: req.body.user_id
    }

    if(!data.id || !data.species || !data.age || !data.height || !data.user_id){
        res.status(400).json("message: Missing required data.")
    }

    const callback = (error, results, fields) => {
        if(error){
            console.error("Error updateTree: ", error)
            return res.status(500).json(error)
        }else{
            if(results.affectedRows === 0){
                res.status(404).json({message: "Tree not found"})
            }else
            res.status(204).json()
        }

    }
    treesModel.updateTree(data, callback)
}
// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR DELETE TREE BY ID
// ##############################################################
module.exports.deleteTree = (req, res, next) =>
{
    const data = {
        id: req.params.id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error deletePlayerById:", error);
            return res.status(500).json(error);
        } else {
            if(results.affectedRows == 0) 
            {
                return res.status(404).json({message: "Tree not found"});
            }
            else return res.status(204).send();           
        }
    }

    treesModel.deleteTree(data, callback);
}