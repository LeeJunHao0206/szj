document.addEventListener("DOMContentLoaded", function () {
  const callback = (responseStatus, responseData) => {
    console.log("responseStatus:", responseStatus);
    console.log("responseData:", responseData);

    const pokedexList = document.getElementById("pokedexList");
    responseData.forEach((pokedex) => {
      const displayItem = document.createElement("div");
      displayItem.className =
        "col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-12 p-3";
      displayItem.innerHTML = `
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">ID: ${pokedex.number}</h5>
                <p class="card-text">
                    Name: ${pokedex.name} <br>
                    Type1: ${pokedex.type1} <br>
                    Type2: ${pokedex.type2} <br>
                </p>
            </div>
        </div>
        `;
      pokedexList.append(displayItem);
    });
  };

  fetchMethod(currentUrl + "/api/pokedex", callback, "GET");
});