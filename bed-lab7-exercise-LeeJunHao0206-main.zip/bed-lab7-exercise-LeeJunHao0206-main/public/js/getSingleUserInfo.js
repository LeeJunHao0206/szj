document.addEventListener("DOMContentLoaded", function () {
  const url = new URL(window.location.href);
  const userId = url.searchParams.get("user_id");

  const userInfo = document.getElementById("userInfo");
  const playerList = document.getElementById("playerList");

  /* =========================
     GUARD: missing user_id
  ========================= */
  if (!userId) {
    userInfo.innerHTML = "No user ID provided.";
    return;
  }

  /* =========================
     USER INFO CALLBACK
  ========================= */
  const callbackForUserInfo = (status, data) => {
    if (status === 404) {
      userInfo.innerHTML = data.message;
      return;
    }

    userInfo.innerHTML = `
      <div class="card">
        <div class="card-body">
          <p>
            <strong>User ID:</strong> ${data.id}<br>
            <strong>Username:</strong> ${data.username}<br>
            <strong>Email:</strong> ${data.email}<br>
            <strong>Created On:</strong> ${data.created_on}<br>
            <strong>Updated On:</strong> ${data.updated_on}<br>
            <strong>Last Login On:</strong> ${data.last_login_on}
          </p>
        </div>
      </div>
    `;
  };

  /* =========================
     USER PLAYERS CALLBACK
  ========================= */
  const callbackForUserPlayers = (status, data) => {
    if (status === 404) {
      playerList.innerHTML = data.message;
      return;
    }

    if (data.length === 0) {
      playerList.innerHTML = "<p>No characters found.</p>";
      return;
    }

    playerList.innerHTML = "";

    data.forEach(player => {
      playerList.innerHTML += `
        <div class="card mb-3">
          <div class="card-body">
            <p>
              <strong>Character Name:</strong> ${player.character_name}<br>
              <strong>User ID:</strong> ${player.user_id}<br>
              <strong>Player ID:</strong> ${player.player_id}<br>
              <strong>Username:</strong> ${player.username}<br>
              <strong>Character Level:</strong> ${player.character_level}<br>
              <strong>Character Created On:</strong> ${player.char_created_on}<br>
              <strong>User Created On:</strong> ${player.user_created_on}
            </p>
          </div>
        </div>
      `;
    });
  };

  /* =========================
     FETCH REQUESTS
  ========================= */
  fetchMethod(`${currentUrl}/api/user/${userId}`, callbackForUserInfo, "GET");
  fetchMethod(`${currentUrl}/api/user/${userId}/player`, callbackForUserPlayers, "GET");
});
