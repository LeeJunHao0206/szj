const pool = require('../services/db');

module.exports.selectAll = (callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM Player;
    `;

pool.query(SQLSTATMENT, callback);
}

module.exports.selectById = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM Player
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.insertSingle = (data, callback) =>
{
    const SQLSTATMENT = `
    INSERT INTO Player (name, level)
    VALUES (?, ?);
    `;
const VALUES = [data.name, data.level];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.updateById = (data, callback) =>
{
    const SQLSTATMENT = `
    UPDATE tree 
    SET species = ?, age = ?, height = ?, watered_on = NOW(), planted_on = NOW(), user_id = ?
    WHERE id = ?;
    `;
const VALUES = [data.species, data.age, data.height, ];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.deleteById = (data, callback) =>
{
    const SQLSTATMENT = `
    DELETE FROM Player 
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.insertNewPLayerwithUser = (data, callback) =>
{
    const SQLSTATMENT = `
    INSERT INTO Player (name, level, user_id)
    VALUES (?, ?, ?);
    `;
const VALUES = [data.name, data.level, data.user_id];

pool.query(SQLSTATMENT, VALUES, callback);
}