const pool = require('../services/db');

module.exports.readAllPokemon = (callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM Pokemon;
    `;

pool.query(SQLSTATMENT, callback);

}

module.exports.insertSingle = (data, callback) =>
{
    const SQLSTATMENT = `
    INSERT INTO Pokemon (id, owner_id, dex_num, hp, atk, def)
    VALUES(?, ?, ?, ?, ?, ?);
    `;
const VALUES = [data.id, data.owner_id, data.dex_num, data.hp, data.atk, data.def];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.selectById = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM Pokemon
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.selectByIdWithDexInfo = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT * FROM Pokemon
    WHERE id = ?;
    `;
const VALUES = [data.id];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.selectAllWithDexInfo = (callback) =>
{
    const SQLSTATMENT = `
    SELECT 
    p.id,
    p.owner_id,
    p.dex_num,
    p.hp,
    p.atk,
    p.def,
    d.name AS dex_name,
    d.type1,
    d.type2
  FROM Pokemon p
  JOIN Pokedex d ON p.dex_num = d.number;
`;


pool.query(SQLSTATMENT, callback);
}