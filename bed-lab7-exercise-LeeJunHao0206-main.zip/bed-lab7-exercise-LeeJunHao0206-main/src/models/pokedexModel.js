const pool = require("../services/db");

module.exports.readAllPokedex = (callback) => {
  const SQLSTATMENT = `
    SELECT * FROM pokedex;
    `;

  pool.query(SQLSTATMENT, callback);
};

module.exports.readPokedexByNumber = (data, callback) => {
  const SQLSTATMENT = `
    SELECT * FROM pokedex
    WHERE number = ?;
    `;

  const VALUES = [data.number];
  pool.query(SQLSTATMENT, VALUES, callback);
};
