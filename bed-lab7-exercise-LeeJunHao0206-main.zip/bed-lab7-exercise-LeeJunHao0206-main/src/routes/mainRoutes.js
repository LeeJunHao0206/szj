//////////////////////////////////////////////////////
// REQUIRE MODULES
//////////////////////////////////////////////////////
const express = require("express");
const router = express.Router()
//////////////////////////////////////////////////////
// CREATE ROUTER
//////////////////////////////////////////////////////
const exampleController = require("../controllers/exampleController")
const jwtMiddleware = require("../middlewares/jwtMiddleware")
const bcryptMiddleware = require("../middlewares/bcryptMiddleware")

const userController = require("../controllers/userController")

const userRoutes = require("./userRoutes")
router.use("/user", userRoutes)
const playerRoutes = require("./playerRoutes")
router.use("/player", playerRoutes)
const pokedexRoutes = require("./pokedexRoutes")
router.use("/pokedex", pokedexRoutes)
const pokemonRoutes = require("./pokemonRoutes")
router.use("/pokemon", pokemonRoutes)
//////////////////////////////////////////////////////
// DEFINE ROUTES
//////////////////////////////////////////////////////
router.post("/login", userController.login, bcryptMiddleware.comparePassword, jwtMiddleware.generateToken, jwtMiddleware.sendToken);
router.post("/register", userController.checkUsernameOrEmailExist, bcryptMiddleware.hashPassword, userController.register, jwtMiddleware.generateToken, jwtMiddleware.sendToken);

router.post("/players", jwtMiddleware.verifyToken, userController.createNewPlayer, userController.updatePlayeruserrel, userController.sendUserInfo)
router.put("/player/:playerId", jwtMiddleware.verifyToken, userController.updatePlayer, userController.sendUserInfo)
router.delete("/player/:playerId", jwtMiddleware.verifyToken, userController.deletePlayer)
router.post("/pokemon", jwtMiddleware.verifyToken, userController.createNewPokemon, userController.showPokemonData)

router.post("/jwt/generate", exampleController.preTokenGenerate, jwtMiddleware.generateToken, exampleController.beforeSendToken, jwtMiddleware.sendToken);
router.get("/jwt/verify", jwtMiddleware.verifyToken, exampleController.showTokenVerified);
router.post("/bcrypt/compare", exampleController.preCompare, bcryptMiddleware.comparePassword, exampleController.showCompareSuccess);
router.post("/bcrypt/hash", bcryptMiddleware.hashPassword, exampleController.showHashing);

//////////////////////////////////////////////////////
// EXPORT ROUTER
//////////////////////////////////////////////////////
module.exports = router