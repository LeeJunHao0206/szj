const express = require("express");
const router = express.Router()

const controller = require("../controllers/pokedexController");

router.get('/', controller.readAllPokedex);
router.get("/:number", controller.readPokedexByNumber)

module.exports = router;