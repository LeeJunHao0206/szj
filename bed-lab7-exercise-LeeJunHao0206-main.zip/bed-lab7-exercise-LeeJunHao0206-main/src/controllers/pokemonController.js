const model = require("../models/pokemonModel")

module.exports.readAllPokemon = (req, res, next) =>
{
    const callback = (error, results, fields) =>
    {
        if(error){
            console.log("Error readAllPokemon: ", error)
            return res.status(500).json({message: "Internal system error"})
        }
        return res.status(200).json(results)
    }
    model.readAllPokemon(callback)
}

module.exports.readAllPokemonWithDexInfo = (req, res, next) =>
{
 try{
    let merge = [];
    for(let i = 0; i < data.pokemon.length; i++){
        for(let j = 0; j < data.pokedex.length; j++){
            if(data.pokemon[i].dex_num === data.pokedex[j].number){
                merge.push(Object.assign({}, data.pokemon[i], data.pokedex[j]));
            }
        }
    }

    data.dex_info = merge;

    res.status(200).json(data.dex_info)
 }  
 catch(error){
    console.log("Error readAllPokemonWithDexInfo: ",error);
    res.status(400).json(error)
 } 
}

module.exports.createPokemon = (req, res, next) =>
{
    if(req.body.dex_num == undefined){
        res.status(400).send("Error: name is undefined");
    return;
    }

    try{
        const pokemon = {
            id: data.pokemon.length + 1,
            owner_id: req.body.owner_id,
            dex_num: req.body.dex_num,
            hp: req.body.hp,
            atk: req.body.atk,
            def: req.body.def
        }
        data.pokemon.push(pokemon)
    }
    catch(error){
        console.error("Error createNewPokemon: ", error);
        res.status(500).json(error);
    }
}

module.exports.readPokemonById = (req, res, next) =>
{   
    try{
        const id = req.params.id;
        const details = data.pokemon.find(pokemon => pokemon.id == id);

        if(id == undefined){
            console.log("Error readPokemonById: ", error);
            res.status(404).send("Pokemon not found");
        }else{
            res.status(200).json(details);
        }
    }
    catch(error){
        console.log("Error readPokemonById: ", error);
        res.status(500).json(error);
    }
}

module.exports.readPokemonByIdWithDexInfo = (req, res, next) =>
{   
    try {
    const id = parseInt(req.params.id);
    const pokemon = data.pokemon.find((x) => x.id === id);
    if (!pokemon) {
      return res.status(404).json({ Error: "Pokemon ID Not Found" });
    }

    const dex = data.pokedex.find((y) => y.number === pokemon.dex_num);
    res.status(200).json({ ...pokemon, ...dex });
  } catch (error) {
    next(error);
  }
}