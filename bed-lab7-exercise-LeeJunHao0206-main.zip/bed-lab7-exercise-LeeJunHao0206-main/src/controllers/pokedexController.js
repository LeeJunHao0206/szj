const model = require("../models/pokedexModel");

module.exports.getRandomDex = (req, res, next) => {
  try {
    const number = Math.floor(Math.random() * data.pokedex.length);
    const randomPokemon = data.pokedex[number];

    if (pokeDex_details == undefined) {
      res.status(404).send("Pokedex not found");
    } else {
      res.status(200).json(randomPokemon);
    }
  } catch (error) {
    console.log("Error getRandomDex: ", error);
    req.status(400).json(error);
  }
};

module.exports.readAllPokedex = (req, res, next) => {
  const callback = (error, results, fields) => {
    if (error) {
      console.log("Error readAllPokedex: ", error);
      return res.status(500).json({ message: "Internal server error" });
    }
    return res.status(200).json(results);
  };
  model.readAllPokedex(callback);
};

module.exports.readPokedexByNumber = (req, res, next) => {
  if (!req.params.number) {
    return res.status(400).json({message: "Missing required data"})
  }

  const data = {
    number: req.params.number
  }

  const callback = (error, results, fields) =>
  {
    if (error) {
      console.log("Error readPokedexByNumber: ", error);
      return res.status(500).json({ message: "Internal server error" });
    }
    return res.status(200).json(results)
  }
  model.readPokedexByNumber(data, callback)
};
module.exports.createNewPokedex = (req, res, next) => {
  if (req.body.name == undefined) {
    res.status(400).send("Error: name is undefined");
  }

  try {
    const pokedex = {
      number: data.pokedex.length + 1,
      name: req.body.name,
      type1: req.body.type1,
      type2: req.body.type2,
    };
    data.pokedex.push(pokedex);

    res.status(201).json({
      message: "Pokedex created",
    });
  } catch (error) {
    console.error("Error createNewPokedex: ", error);
    res.status(500).json(error);
  }
};

module.exports.updatePokedexByNumber = (req, res, next) => {
  if (req.body.name == undefined) {
    res.status(400).json({ message: "Error: name is undefined" });
    return;
  }

  try {
    const number = parseInt(req.params.number);
    const pokedex = data.pokedex.find((pokedex) => pokedex.number === number);
    //parseInt
    if (pokedex == undefined) {
      res.status(404).json({ message: "Pokedex not found" });
    } else {
      pokedex.name = req.body.name;
      pokedex.type1 = req.body.type1;
      pokedex.type2 = req.body.type2;
      res.status(204).send();
    }
  } catch (error) {
    console.log("Error updatePokedexByNumber: ", error);
    res.status(500).json(error);
  }
};

module.exports.deletePokedexByNumber = (req, res, next) => {
  try {
    const name = req.params.name;
    const details = data.pokedex.find((p) => p.name === name);

    if (details == undefined) {
      res.status(404).send("Pokedex not found");
    } else {
      data.player = data.player.filter((player) => player.id != id);
      res.status(204).send("Pokedex has been deleted");
    }
  } catch (error) {
    console.error("Error deletePokedexById: ", error);
    res.status(500).json(error);
  }
};
